const { defineConfig, transformWithOxc } = require("vite");
const react = require("@vitejs/plugin-react").default;

module.exports = defineConfig({
  plugins: [
    {
      name: "treat-source-js-as-jsx",
      enforce: "pre",
      async transform(code, id) {
        if (!/\/src\/.*\.js$/.test(id)) return null;
        return transformWithOxc(code, id, { lang: "jsx" });
      },
    },
    react(),
  ],
  build: {
    outDir: "build",
    emptyOutDir: true,
  },
});