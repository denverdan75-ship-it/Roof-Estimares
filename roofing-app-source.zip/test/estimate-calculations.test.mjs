import assert from "node:assert/strict";
import test from "node:test";
import { createEstimate } from "../src/api/client.js";
import { calculateMeasurements, calculatePricedLineItems, calculateTotals } from "../src/calculations.mjs";

test("converts square feet to roofing squares and applies waste", () => {
  assert.deepEqual(
    calculateMeasurements(2000, "sqft", 10),
    {
      inputValue: 2000,
      inputUnit: "sqft",
      baseSqFt: 2000,
      baseSquares: 20,
      squares: 22,
      wastePercent: 10,
    },
  );
});

test("converts roofing squares to square feet and applies waste", () => {
  const measurements = calculateMeasurements(24, "squares", 12.5);

  assert.equal(measurements.baseSqFt, 2400);
  assert.equal(measurements.baseSquares, 24);
  assert.equal(measurements.squares, 27);
});

test("prices square, square-foot, and flat line items", () => {
  const measurements = calculateMeasurements(2000, "sqft", 10);
  const pricedItems = calculatePricedLineItems(
    [
      { id: "shingles", name: "Shingles", unit: "square", rate: 145 },
      { id: "underlayment", name: "Underlayment", unit: "sqft", rate: 1.25 },
      { id: "delivery", name: "Delivery", unit: "flat", quantity: 1, rate: 350 },
    ],
    measurements,
  );

  assert.deepEqual(pricedItems.map(({ quantity, rate, total }) => ({ quantity, rate, total })), [
    { quantity: 22, rate: 145, total: 3190 },
    { quantity: 2000, rate: 1.25, total: 2500 },
    { quantity: 1, rate: 350, total: 350 },
  ]);
});

test("calculates subtotal, overhead, markup, tax, and total", () => {
  const totals = calculateTotals(
    [{ total: 1000 }, { total: 500 }],
    { overheadPercent: 10, markupPercent: 20, taxPercent: 8.25 },
  );

  assert.deepEqual(totals, {
    subtotal: 1500,
    overhead: 150,
    markedUp: 330,
    tax: 163.35,
    total: 2143.35,
  });
});

test("rejects invalid estimate rates, quantities, and percentages before calculating", async () => {
  const { calculateEstimateData } = await import("../server.js");
  const baseEstimate = {
    customerName: "Jordan Smith",
    address: "118 Birch St",
    measurements: { inputValue: 24, inputUnit: "squares", wastePercent: 10 },
    lineItems: [{ id: "shingles", name: "Shingles", unit: "square", quantity: 1, rate: 145 }],
    pricing: { overheadPercent: 10, markupPercent: 20, taxPercent: 8.25 },
  };

  await assert.rejects(
    calculateEstimateData({ ...baseEstimate, lineItems: [{ ...baseEstimate.lineItems[0], rate: -1 }] }),
    (error) => error.statusCode === 400 && error.message === "Line item 1 rate must be a non-negative number.",
  );
  await assert.rejects(
    calculateEstimateData({ ...baseEstimate, lineItems: [{ ...baseEstimate.lineItems[0], quantity: "not-a-number" }] }),
    (error) => error.statusCode === 400 && error.message === "Line item 1 quantity must be a non-negative number.",
  );
  await assert.rejects(
    calculateEstimateData({ ...baseEstimate, pricing: { ...baseEstimate.pricing, taxPercent: 101 } }),
    (error) => error.statusCode === 400 && error.message === "taxPercent must be a percentage between 0 and 100.",
  );
});

test("recalculates and preserves saved estimate values after JSON round-trip", async () => {
  const { calculateEstimateData } = await import("../server.js");
  const estimate = {
    customerName: "Jordan Smith",
    address: "118 Birch St",
    measurements: {
      inputValue: 2000,
      inputUnit: "sqft",
      wastePercent: 10,
      squares: 22,
    },
    lineItems: [
      { id: "shingles", name: "Shingles", unit: "square", quantity: 999, rate: 145, total: 999 },
      { id: "delivery", name: "Delivery", unit: "flat", quantity: 1, rate: 350, total: 350 },
    ],
    pricing: { overheadPercent: 10, markupPercent: 20, taxPercent: 8.25 },
    totals: { subtotal: 1, overhead: 2, markedUp: 3, tax: 4, total: 5 },
  };

  const storedEstimate = await calculateEstimateData(estimate);
  const reopenedEstimate = JSON.parse(JSON.stringify(storedEstimate));

  assert.deepEqual(reopenedEstimate, storedEstimate);
  assert.deepEqual(storedEstimate.measurements, {
    inputValue: 2000,
    inputUnit: "sqft",
    baseSqFt: 2000,
    baseSquares: 20,
    squares: 22,
    wastePercent: 10,
  });
  assert.deepEqual(storedEstimate.totals, {
    subtotal: 3540,
    overhead: 354,
    markedUp: 778.8000000000001,
    tax: 385.50600000000003,
    total: 5058.3060000000005,
  });

  const originalFetch = globalThis.fetch;
  const requests = [];
  globalThis.fetch = async (path, options) => {
    requests.push({ path, options });
    const persisted = await calculateEstimateData(JSON.parse(options.body));
    return { ok: true, json: async () => persisted };
  };

  try {
    const reopenedFromApi = await createEstimate(storedEstimate);
    assert.equal(requests[0].path, "/estimates");
    assert.equal(requests[0].options.method, "POST");
    assert.deepEqual(JSON.parse(requests[0].options.body), storedEstimate);
    assert.deepEqual(reopenedFromApi, storedEstimate);
  } finally {
    globalThis.fetch = originalFetch;
  }
});