import assert from "node:assert/strict";
import { createRequire } from "node:module";
import test from "node:test";
import { updateEstimateStatus } from "../src/api/client.js";
import { ESTIMATE_STATUSES } from "../src/estimateStatuses.js";

const require = createRequire(import.meta.url);
const { validEstimateStatus } = require("../server.js");

test("supports every job stage and rejects unknown stages", () => {
  assert.deepEqual(ESTIMATE_STATUSES, ["Draft", "Sent", "Approved", "Scheduled", "Completed", "Declined"]);
  ESTIMATE_STATUSES.forEach((status) => assert.equal(validEstimateStatus(status), true));
  assert.equal(validEstimateStatus("Cancelled"), false);
  assert.equal(validEstimateStatus("draft"), false);
});

test("sends focused status updates to the estimate endpoint", async () => {
  const originalFetch = globalThis.fetch;
  let request;
  globalThis.fetch = async (path, options) => {
    request = { path, options };
    return {
      ok: true,
      json: async () => ({ estimate_id: 42, status: "Approved" }),
    };
  };

  try {
    const saved = await updateEstimateStatus(42, "Approved");
    assert.equal(request.path, "/estimates/42/status");
    assert.equal(request.options.method, "PATCH");
    assert.deepEqual(JSON.parse(request.options.body), { status: "Approved" });
    assert.equal(saved.status, "Approved");
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("surfaces the server validation message from failed estimate requests", async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => ({
    ok: false,
    status: 400,
    statusText: "Bad Request",
    text: async () => JSON.stringify({ error: "Line item 1 rate must be a non-negative number." }),
  });

  try {
    await assert.rejects(
      updateEstimateStatus(42, "Approved"),
      new Error("Request failed (400): Line item 1 rate must be a non-negative number."),
    );
  } finally {
    globalThis.fetch = originalFetch;
  }
});