import assert from "node:assert/strict";
import test from "node:test";
import {
  createEstimate,
  createPricingPackage,
  createPricingPreset,
  deletePricingPackage,
  deletePricingPreset,
  listEstimates,
  listPricingPackages,
  listPricingPresets,
  updateEstimate,
  updatePricingPackage,
  updatePricingPreset,
} from "../src/api/client.js";

const { calculateEstimateData } = await import("../server.js");

function response(body, status = 200) {
  return {
    ok: status >= 200 && status < 300,
    status,
    statusText: status === 200 ? "OK" : "Created",
    json: async () => structuredClone(body),
    text: async () => JSON.stringify(body),
  };
}

async function withFetch(fetchHandler, callback) {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = fetchHandler;

  try {
    return await callback();
  } finally {
    globalThis.fetch = originalFetch;
  }
}

function lineItemDetails(lineItems) {
  return lineItems.map(({ name, category, unit, quantity, rate }) => ({
    name,
    category,
    unit,
    quantity,
    rate,
  }));
}

test("preserves customized line items, reordering, and per-estimate rates after reload", async () => {
  let savedEstimate;
  const requests = [];
  const estimate = {
    customerName: "Jordan Smith",
    address: "118 Birch St",
    measurements: {
      inputValue: 24,
      inputUnit: "squares",
      wastePercent: 10,
    },
    lineItems: [
      {
        id: "custom-installation",
        name: "Custom installation",
        category: "service",
        unit: "hour",
        quantity: 3.5,
        rate: 92.5,
      },
      {
        id: "copper-flashing",
        name: "Copper flashing",
        category: "material",
        unit: "linear-foot",
        quantity: 42,
        rate: 18.75,
      },
      {
        id: "permit",
        name: "Permit",
        category: "service",
        unit: "flat",
        quantity: 1,
        rate: 275,
      },
    ],
    pricing: { overheadPercent: 10, markupPercent: 20, taxPercent: 0 },
  };

  await withFetch(async (path, options = {}) => {
    requests.push({ path, options });
    if (path === "/estimates" && options.method === "POST") {
      const data = await calculateEstimateData(JSON.parse(options.body));
      savedEstimate = { ...data, estimate_id: 42 };
      return response(savedEstimate, 201);
    }
    if (path === "/estimates/42" && options.method === "PUT") {
      const data = await calculateEstimateData(JSON.parse(options.body));
      savedEstimate = { ...data, estimate_id: 42 };
      return response(savedEstimate);
    }
    if (path === "/estimates" && !options.method) {
      return response([savedEstimate]);
    }
    throw new Error(`Unexpected request: ${options.method || "GET"} ${path}`);
  }, async () => {
    const created = await createEstimate(estimate);
    assert.deepEqual(lineItemDetails(created.lineItems), lineItemDetails(estimate.lineItems));

    const reorderedItems = [created.lineItems[2], created.lineItems[0], created.lineItems[1]];
    const updated = await updateEstimate(created.estimate_id, {
      ...created,
      lineItems: reorderedItems,
    });
    assert.deepEqual(lineItemDetails(updated.lineItems), lineItemDetails(reorderedItems));

    const [reopened] = await listEstimates();
    assert.deepEqual(lineItemDetails(reopened.lineItems), lineItemDetails(reorderedItems));
    assert.deepEqual(
      reopened.lineItems.map(({ id }) => id),
      ["permit", "custom-installation", "copper-flashing"],
    );
    assert.deepEqual(
      requests.map(({ path, options }) => `${options.method || "GET"} ${path}`),
      ["POST /estimates", "PUT /estimates/42", "GET /estimates"],
    );
  });
});

test("allows an estimate to intentionally contain no line items", async () => {
  let savedEstimate;

  await withFetch(async (path, options = {}) => {
    if (path === "/estimates" && options.method === "POST") {
      const data = await calculateEstimateData(JSON.parse(options.body));
      savedEstimate = { ...data, estimate_id: 43 };
      return response(savedEstimate, 201);
    }
    if (path === "/estimates" && !options.method) {
      return response([savedEstimate]);
    }
    throw new Error(`Unexpected request: ${options.method || "GET"} ${path}`);
  }, async () => {
    const saved = await createEstimate({
      customerName: "Casey Lee",
      address: "204 Oak Ave",
      measurements: { inputValue: 18, inputUnit: "squares", wastePercent: 0 },
      lineItems: [],
      pricing: {},
    });

    assert.deepEqual(saved.lineItems, []);
    const [reopened] = await listEstimates();
    assert.deepEqual(reopened.lineItems, []);
  });
});

test("supports pricing preset create, edit, use, and delete through the API", async () => {
  let nextId = 1;
  let presets = [];
  const requests = [];

  await withFetch(async (path, options = {}) => {
    requests.push({ path, options });
    if (path === "/pricing-presets" && !options.method) {
      return response(presets);
    }
    if (path === "/pricing-presets" && options.method === "POST") {
      const incoming = JSON.parse(options.body);
      const created = { ...incoming, id: `preset-${nextId++}`, rate: Number(incoming.rate) };
      presets = [...presets, created];
      return response(created, 201);
    }
    if (path.startsWith("/pricing-presets/") && options.method === "PUT") {
      const id = path.split("/").pop();
      const incoming = JSON.parse(options.body);
      const current = presets.find((preset) => preset.id === id);
      const updated = { ...current, ...incoming, id, rate: Number(incoming.rate) };
      presets = presets.map((preset) => (preset.id === id ? updated : preset));
      return response(updated);
    }
    if (path.startsWith("/pricing-presets/") && options.method === "DELETE") {
      const id = path.split("/").pop();
      presets = presets.filter((preset) => preset.id !== id);
      return response(presets);
    }
    throw new Error(`Unexpected request: ${options.method || "GET"} ${path}`);
  }, async () => {
    const created = await createPricingPreset({
      name: "Premium ice guard",
      category: "material",
      unit: "sqft",
      rate: 4.25,
    });
    assert.deepEqual(created, {
      id: "preset-1",
      name: "Premium ice guard",
      category: "material",
      unit: "sqft",
      rate: 4.25,
    });

    const edited = await updatePricingPreset(created.id, {
      name: "Premium ice guard installation",
      category: "service",
      unit: "linear-foot",
      rate: 5.5,
    });
    assert.deepEqual(edited, {
      id: "preset-1",
      name: "Premium ice guard installation",
      category: "service",
      unit: "linear-foot",
      rate: 5.5,
    });

    const [availablePreset] = await listPricingPresets();
    const usedLineItem = {
      ...availablePreset,
      presetId: availablePreset.id,
      quantity: 12,
    };
    assert.deepEqual(
      { name: usedLineItem.name, category: usedLineItem.category, unit: usedLineItem.unit, rate: usedLineItem.rate },
      { name: edited.name, category: edited.category, unit: edited.unit, rate: edited.rate },
    );

    const remaining = await deletePricingPreset(edited.id);
    assert.deepEqual(remaining, []);
    assert.deepEqual(await listPricingPresets(), []);
    assert.deepEqual(
      requests.map(({ path, options }) => `${options.method || "GET"} ${path}`),
      [
        "POST /pricing-presets",
        "PUT /pricing-presets/preset-1",
        "GET /pricing-presets",
        "DELETE /pricing-presets/preset-1",
        "GET /pricing-presets",
      ],
    );
  });
});

test("supports ordered pricing package create, edit, use, and delete through the API", async () => {
  let nextPackageId = 1;
  let packages = [];
  const presets = [
    { id: "shingles", name: "Shingles", category: "material", unit: "square", rate: 145 },
    { id: "install", name: "Installation", category: "service", unit: "square", rate: 85 },
  ];
  const requests = [];

  await withFetch(async (path, options = {}) => {
    requests.push({ path, options });
    if (path === "/pricing-packages" && !options.method) return response(packages);
    if (path === "/pricing-packages" && options.method === "POST") {
      const incoming = JSON.parse(options.body);
      const created = { ...incoming, id: `package-${nextPackageId++}` };
      packages = [...packages, created];
      return response(created, 201);
    }
    if (path.startsWith("/pricing-packages/") && options.method === "PUT") {
      const id = path.split("/").pop();
      const incoming = JSON.parse(options.body);
      const updated = { ...packages.find((savedPackage) => savedPackage.id === id), ...incoming, id };
      packages = packages.map((savedPackage) => (savedPackage.id === id ? updated : savedPackage));
      return response(updated);
    }
    if (path.startsWith("/pricing-packages/") && options.method === "DELETE") {
      const id = path.split("/").pop();
      packages = packages.filter((savedPackage) => savedPackage.id !== id);
      return response(packages);
    }
    throw new Error(`Unexpected request: ${options.method || "GET"} ${path}`);
  }, async () => {
    const created = await createPricingPackage({ name: "Asphalt replacement", presetIds: [presets[0].id, presets[1].id] });
    assert.deepEqual(created, {
      id: "package-1",
      name: "Asphalt replacement",
      presetIds: ["shingles", "install"],
    });

    const edited = await updatePricingPackage(created.id, {
      name: "Asphalt replacement with tear-off",
      presetIds: ["install", "shingles"],
    });
    assert.deepEqual(edited.presetIds, ["install", "shingles"]);

    const [availablePackage] = await listPricingPackages();
    const copiedRows = availablePackage.presetIds.map((presetId) => presets.find((preset) => preset.id === presetId));
    assert.deepEqual(copiedRows.map(({ id }) => id), ["install", "shingles"]);
    assert.deepEqual(copiedRows.map(({ name, rate }) => ({ name, rate })), [
      { name: "Installation", rate: 85 },
      { name: "Shingles", rate: 145 },
    ]);

    assert.deepEqual(await deletePricingPackage(edited.id), []);
    assert.deepEqual(
      requests.map(({ path, options }) => `${options.method || "GET"} ${path}`),
      [
        "POST /pricing-packages",
        "PUT /pricing-packages/package-1",
        "GET /pricing-packages",
        "DELETE /pricing-packages/package-1",
      ],
    );
  });
});