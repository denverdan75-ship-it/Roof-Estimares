# Roofing Estimates

A roofing estimate and job-management app with a React/Vite interface, an Express API, and PostgreSQL persistence.

## Features

- Public customer intake form and protected administrator workspace
- New Leads list with customer details and lead-to-estimator conversion
- Roof measurement, line-item pricing, estimate, and proposal workflows
- Estimate documents and job pipeline status management

## Requirements

- Node.js compatible with the versions required by the packages in `package.json`
- PostgreSQL database

## Configure the runtime

Set these environment variables in the hosting service's secret/environment settings. Do not commit their values to GitHub:

- `DATABASE_URL` — PostgreSQL connection string
- `ADMIN_PASSWORD` — administrator sign-in password
- `SESSION_SECRET` — long, random value used to sign administrator sessions
- `PORT` — optional; the app defaults to port `3000`

The server creates the `leads` and `estimate_documents` tables if missing. The existing database schema for estimates and pricing settings is not included in this source repository. Migrate or provision that schema separately before running the app. Customer records and uploaded documents are also database data and are not included in the source files.

## Run locally

```sh
npm install
npm run serve
```

The server listens on the configured `PORT`, or `http://localhost:3000` when `PORT` is not set.

## Build and test

```sh
npm run build
npm test
```

This repository contains application source code. GitHub stores and edits that code; it does not, by itself, run this Express server or host the PostgreSQL database.