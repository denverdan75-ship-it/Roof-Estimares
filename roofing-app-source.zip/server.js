const path = require("path");
const express = require("express");
const { Pool } = require("pg");
const crypto = require("crypto");
const { ZipArchive } = require("archiver");
const { PDFDocument } = require("pdf-lib");

if (!process.env.SESSION_SECRET || !process.env.ADMIN_PASSWORD) {
  throw new Error("SESSION_SECRET and ADMIN_PASSWORD are required to start the application securely.");
}

const app = express();
app.set("trust proxy", 1);
const SESSION_COOKIE = "dragonfly_session";
const SESSION_DURATION_MS = 12 * 60 * 60 * 1000;
const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const MAX_LOGIN_ATTEMPTS = 5;
const loginAttempts = new Map();
const LEAD_WINDOW_MS = 15 * 60 * 1000;
const MAX_LEAD_SUBMISSIONS = 5;
const leadSubmissions = new Map();
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});
const defaultLineItemPresets = [
  { id: "roofing-materials", name: "Roofing materials", category: "material", unit: "square", rate: 145 },
  { id: "installation-labor", name: "Installation labor", category: "service", unit: "square", rate: 85 },
  { id: "tear-off", name: "Tear-off", category: "service", unit: "square", rate: 45 },
  { id: "disposal-delivery", name: "Disposal and delivery", category: "service", unit: "flat", rate: 350 },
];

const defaultPricing = {
  materialPerSquare: 145,
  laborPerSquare: 85,
  tearOffPerSquare: 45,
  disposalFee: 350,
  overheadPercent: 10,
  markupPercent: 20,
  taxPercent: 0,
  lineItemPresets: defaultLineItemPresets,
  pricingPackages: [],
};
const estimateStatuses = new Set(["Draft", "Sent", "Approved", "Scheduled", "Completed", "Declined"]);

function validEstimateStatus(status) {
  return estimateStatuses.has(status);
}

class EstimateValidationError extends Error {
  constructor(message) {
    super(message);
    this.statusCode = 400;
  }
}

function isNonNegativeNumber(value, maximum = Number.POSITIVE_INFINITY) {
  if (value === null || value === undefined) return false;
  if (typeof value === "string" && value.trim() === "") return false;
  if (!["number", "string"].includes(typeof value)) return false;
  const number = Number(value);
  return Number.isFinite(number) && number >= 0 && number <= maximum;
}

function validateEstimatePricing(data) {
  const lineItems = data?.lineItems;
  if (Array.isArray(lineItems)) {
    lineItems.forEach((item, index) => {
      if (!item || typeof item !== "object") {
        throw new EstimateValidationError(`Line item ${index + 1} must be an object.`);
      }
      if (!isNonNegativeNumber(item.rate)) {
        throw new EstimateValidationError(`Line item ${index + 1} rate must be a non-negative number.`);
      }
      if (item.quantity !== undefined && !isNonNegativeNumber(item.quantity)) {
        throw new EstimateValidationError(`Line item ${index + 1} quantity must be a non-negative number.`);
      }
    });
  }

  const pricing = data?.pricing;
  if (pricing && typeof pricing === "object") {
    for (const field of ["overheadPercent", "markupPercent", "taxPercent"]) {
      if (pricing[field] !== undefined && !isNonNegativeNumber(pricing[field], 100)) {
        throw new EstimateValidationError(`${field} must be a percentage between 0 and 100.`);
      }
    }
  }
}

const calculations = import("./src/calculations.mjs");

async function calculateEstimateData(data) {
  validateEstimatePricing(data);
  const { calculateMeasurements, calculatePricedLineItems, calculateTotals } = await calculations;
  const incomingMeasurements = data.measurements || {};
  const inputUnit = incomingMeasurements.inputUnit || "squares";
  const inputValue = incomingMeasurements.inputValue
    ?? (inputUnit === "sqft" ? incomingMeasurements.baseSqFt : incomingMeasurements.baseSquares)
    ?? incomingMeasurements.squares;
  const measurements = calculateMeasurements(inputValue, inputUnit, incomingMeasurements.wastePercent);
  const lineItems = calculatePricedLineItems(
    Array.isArray(data.lineItems) ? data.lineItems : [],
    measurements,
  );
  const totals = calculateTotals(lineItems, data.pricing || {});

  return { ...data, measurements, lineItems, totals };
}

async function readPricingSettings() {
  const result = await pool.query("SELECT data FROM pricing_settings WHERE id = 1");
  return { ...defaultPricing, ...(result.rows[0]?.data || {}) };
}

app.use(express.json({ limit: "15mb" }));

function parseCookies(header = "") {
  return Object.fromEntries(header.split(";").map((part) => {
    const [name, ...value] = part.trim().split("=");
    return [name, decodeURIComponent(value.join("="))];
  }).filter(([name]) => name));
}

function signSession(payload) {
  const encoded = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const signature = crypto.createHmac("sha256", process.env.SESSION_SECRET).update(encoded).digest("base64url");
  return `${encoded}.${signature}`;
}

function readSession(req) {
  const token = parseCookies(req.headers.cookie)[SESSION_COOKIE];
  if (!token) return null;
  const [encoded, signature] = token.split(".");
  if (!encoded || !signature) return null;
  const expected = crypto.createHmac("sha256", process.env.SESSION_SECRET).update(encoded).digest();
  let supplied;
  try {
    supplied = Buffer.from(signature, "base64url");
  } catch {
    return null;
  }
  if (supplied.length !== expected.length || !crypto.timingSafeEqual(supplied, expected)) return null;
  try {
    const session = JSON.parse(Buffer.from(encoded, "base64url").toString("utf8"));
    return session.sub === "admin" && session.exp > Date.now() ? session : null;
  } catch {
    return null;
  }
}

function sessionCookie(value, maxAge) {
  return [
    `${SESSION_COOKIE}=${encodeURIComponent(value)}`,
    "HttpOnly",
    "SameSite=Strict",
    "Path=/",
    `Max-Age=${maxAge}`,
    "Secure",
  ].filter(Boolean).join("; ");
}

function requireAuth(req, res, next) {
  if (!readSession(req)) return res.status(401).json({ error: "Unauthorized" });
  next();
}

function validAdminPassword(password) {
  const supplied = crypto.createHash("sha256").update(String(password || "")).digest();
  const expected = crypto.createHash("sha256").update(String(process.env.ADMIN_PASSWORD || "")).digest();
  return Boolean(process.env.ADMIN_PASSWORD) && crypto.timingSafeEqual(supplied, expected);
}

app.get("/api/auth/session", (req, res) => {
  res.json({ authenticated: Boolean(readSession(req)) });
});

app.post("/api/auth/login", (req, res) => {
  const ip = req.ip;
  const now = Date.now();
  const recent = (loginAttempts.get(ip) || []).filter((attempt) => now - attempt < LOGIN_WINDOW_MS);
  if (recent.length >= MAX_LOGIN_ATTEMPTS) {
    return res.status(429).json({ error: "Too many sign-in attempts. Try again in 15 minutes." });
  }

  if (!validAdminPassword(req.body?.password)) {
    loginAttempts.set(ip, [...recent, now]);
    return res.status(401).json({ error: "Incorrect password." });
  }

  loginAttempts.delete(ip);
  const token = signSession({ sub: "admin", exp: now + SESSION_DURATION_MS });
  res.setHeader("Set-Cookie", sessionCookie(token, Math.floor(SESSION_DURATION_MS / 1000)));
  res.json({ authenticated: true });
});

app.post("/api/auth/logout", (req, res) => {
  res.setHeader("Set-Cookie", sessionCookie("", 0));
  res.json({ authenticated: false });
});

function leadText(value, maxLength = 500) {
  return typeof value === "string" ? value.trim().slice(0, maxLength) : "";
}

app.post("/submit-lead", async (req, res, next) => {
  if (leadText(req.body?.website || req.body?.company_website)) {
    return res.status(201).json({ received: true });
  }

  const ip = req.ip;
  const now = Date.now();
  const recent = (leadSubmissions.get(ip) || []).filter((submittedAt) => now - submittedAt < LEAD_WINDOW_MS);
  if (recent.length >= MAX_LEAD_SUBMISSIONS) {
    const retryAfter = Math.max(1, Math.ceil((LEAD_WINDOW_MS - (now - recent[0])) / 1000));
    res.setHeader("Retry-After", retryAfter);
    return res.status(429).json({ error: "Too many lead submissions. Please try again later." });
  }
  leadSubmissions.set(ip, [...recent, now]);

  const lead = {
    name: leadText(req.body?.name, 200),
    phone: leadText(req.body?.phone, 50),
    email: leadText(req.body?.email, 320),
    serviceType: leadText(req.body?.service_type, 200),
    address: leadText(req.body?.address),
  };
  if (!lead.name || (!lead.phone && !lead.email)) {
    return res.status(400).json({ error: "name and either phone or email are required" });
  }
  try {
    const result = await pool.query(
      `INSERT INTO leads (name, phone, email, service_type, address)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id, name, phone, email, service_type, address`,
      [lead.name, lead.phone, lead.email, lead.serviceType, lead.address],
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    next(error);
  }
});

app.use(["/jobs", "/estimates", "/pricing-settings", "/pricing-presets", "/pricing-packages", "/leads"], requireAuth);

app.get("/leads", async (req, res, next) => {
  try {
    const result = await pool.query(
      "SELECT id, name, phone, email, service_type, address FROM leads ORDER BY id DESC",
    );
    res.json(result.rows);
  } catch (error) {
    next(error);
  }
});

app.get("/jobs", async (req, res, next) => {
  try {
    const result = await pool.query(
      "SELECT job_id, data FROM jobs ORDER BY created_at DESC, job_id DESC",
    );
    res.json(result.rows.map(({ job_id, data }) => ({ ...data, job_id })));
  } catch (error) {
    next(error);
  }
});

app.post("/jobs", async (req, res, next) => {
  const incoming = req.body || {};

  if (!incoming.payload || !incoming.payload.address || !incoming.payload.homeowner_id) {
    return res.status(400).json({ error: "payload.address and payload.homeowner_id are required" });
  }

  try {
    const result = await pool.query(
      "INSERT INTO jobs (data) VALUES ($1::jsonb) RETURNING job_id",
      [JSON.stringify(incoming)],
    );
    res.status(201).json({ ...incoming, job_id: result.rows[0].job_id });
  } catch (error) {
    next(error);
  }
});

app.get("/pricing-settings", async (req, res, next) => {
  try {
    res.json(await readPricingSettings());
  } catch (error) {
    next(error);
  }
});

app.put("/pricing-settings", async (req, res, next) => {
  try {
    const current = await readPricingSettings();
    const pricing = { ...current, ...(req.body || {}) };
    const result = await pool.query(
      `INSERT INTO pricing_settings (id, data, updated_at)
       VALUES (1, $1::jsonb, NOW())
       ON CONFLICT (id) DO UPDATE SET data = EXCLUDED.data, updated_at = NOW()
       RETURNING data`,
      [JSON.stringify(pricing)],
    );
    res.json(result.rows[0].data);
  } catch (error) {
    next(error);
  }
});

app.get("/pricing-presets", async (req, res, next) => {
  try {
    const pricing = await readPricingSettings();
    res.json(pricing.lineItemPresets || []);
  } catch (error) {
    next(error);
  }
});

app.post("/pricing-presets", async (req, res, next) => {
  try {
    const incoming = req.body || {};
    if (!incoming.name?.trim() || !incoming.unit || !Number.isFinite(Number(incoming.rate))) {
      return res.status(400).json({ error: "name, unit, and a valid rate are required" });
    }
    const pricing = await readPricingSettings();
    const preset = {
      id: incoming.id || `preset-${crypto.randomUUID()}`,
      name: incoming.name.trim(),
      category: incoming.category === "service" ? "service" : "material",
      unit: incoming.unit,
      rate: Math.max(0, Number(incoming.rate)),
    };
    const presets = [...(pricing.lineItemPresets || []), preset];
    const result = await pool.query(
      `INSERT INTO pricing_settings (id, data, updated_at)
       VALUES (1, $1::jsonb, NOW())
       ON CONFLICT (id) DO UPDATE SET data = EXCLUDED.data, updated_at = NOW()
       RETURNING data`,
      [JSON.stringify({ ...pricing, lineItemPresets: presets })],
    );
    res.status(201).json(preset);
  } catch (error) {
    next(error);
  }
});

app.put("/pricing-presets/:presetId", async (req, res, next) => {
  try {
    const pricing = await readPricingSettings();
    const presetIndex = (pricing.lineItemPresets || []).findIndex((preset) => preset.id === req.params.presetId);
    if (presetIndex < 0) return res.status(404).json({ error: "Pricing preset not found" });
    const current = pricing.lineItemPresets[presetIndex];
    const incoming = req.body || {};
    if (!incoming.name?.trim() || !incoming.unit || !Number.isFinite(Number(incoming.rate))) {
      return res.status(400).json({ error: "name, unit, and a valid rate are required" });
    }
    const preset = {
      ...current,
      name: incoming.name.trim(),
      category: incoming.category === "service" ? "service" : "material",
      unit: incoming.unit,
      rate: Math.max(0, Number(incoming.rate)),
    };
    const presets = [...pricing.lineItemPresets];
    presets[presetIndex] = preset;
    await pool.query(
      `INSERT INTO pricing_settings (id, data, updated_at)
       VALUES (1, $1::jsonb, NOW())
       ON CONFLICT (id) DO UPDATE SET data = EXCLUDED.data, updated_at = NOW()`,
      [JSON.stringify({ ...pricing, lineItemPresets: presets })],
    );
    res.json(preset);
  } catch (error) {
    next(error);
  }
});

app.delete("/pricing-presets/:presetId", async (req, res, next) => {
  try {
    const pricing = await readPricingSettings();
    const presets = (pricing.lineItemPresets || []).filter((preset) => preset.id !== req.params.presetId);
    if (presets.length === (pricing.lineItemPresets || []).length) {
      return res.status(404).json({ error: "Pricing preset not found" });
    }
    const pricingPackages = (pricing.pricingPackages || []).map((packagePreset) => ({
      ...packagePreset,
      presetIds: (packagePreset.presetIds || []).filter((presetId) => presetId !== req.params.presetId),
    }));
    await pool.query(
      `INSERT INTO pricing_settings (id, data, updated_at)
       VALUES (1, $1::jsonb, NOW())
       ON CONFLICT (id) DO UPDATE SET data = EXCLUDED.data, updated_at = NOW()`,
      [JSON.stringify({ ...pricing, lineItemPresets: presets, pricingPackages })],
    );
    res.json(presets);
  } catch (error) {
    next(error);
  }
});

function validPackagePresetIds(presetIds, presets) {
  if (!Array.isArray(presetIds)) return [];
  const availableIds = new Set(presets.map((preset) => preset.id));
  return [...new Set(presetIds.filter((id) => typeof id === "string" && availableIds.has(id)))];
}

app.get("/pricing-packages", async (req, res, next) => {
  try {
    const pricing = await readPricingSettings();
    res.json(pricing.pricingPackages || []);
  } catch (error) {
    next(error);
  }
});

app.post("/pricing-packages", async (req, res, next) => {
  try {
    const incoming = req.body || {};
    const pricing = await readPricingSettings();
    const presetIds = validPackagePresetIds(incoming.presetIds, pricing.lineItemPresets || []);
    if (!incoming.name?.trim() || !presetIds.length) {
      return res.status(400).json({ error: "name and at least one saved preset are required" });
    }
    const packagePreset = {
      id: incoming.id || `package-${crypto.randomUUID()}`,
      name: incoming.name.trim(),
      presetIds,
    };
    const packages = [...(pricing.pricingPackages || []), packagePreset];
    await pool.query(
      `INSERT INTO pricing_settings (id, data, updated_at)
       VALUES (1, $1::jsonb, NOW())
       ON CONFLICT (id) DO UPDATE SET data = EXCLUDED.data, updated_at = NOW()`,
      [JSON.stringify({ ...pricing, pricingPackages: packages })],
    );
    res.status(201).json(packagePreset);
  } catch (error) {
    next(error);
  }
});

app.put("/pricing-packages/:packageId", async (req, res, next) => {
  try {
    const pricing = await readPricingSettings();
    const packageIndex = (pricing.pricingPackages || []).findIndex(
      (packagePreset) => packagePreset.id === req.params.packageId,
    );
    if (packageIndex < 0) return res.status(404).json({ error: "Pricing package not found" });
    const incoming = req.body || {};
    const presetIds = validPackagePresetIds(incoming.presetIds, pricing.lineItemPresets || []);
    if (!incoming.name?.trim() || !presetIds.length) {
      return res.status(400).json({ error: "name and at least one saved preset are required" });
    }
    const packagePreset = {
      ...pricing.pricingPackages[packageIndex],
      name: incoming.name.trim(),
      presetIds,
    };
    const packages = [...pricing.pricingPackages];
    packages[packageIndex] = packagePreset;
    await pool.query(
      `INSERT INTO pricing_settings (id, data, updated_at)
       VALUES (1, $1::jsonb, NOW())
       ON CONFLICT (id) DO UPDATE SET data = EXCLUDED.data, updated_at = NOW()`,
      [JSON.stringify({ ...pricing, pricingPackages: packages })],
    );
    res.json(packagePreset);
  } catch (error) {
    next(error);
  }
});

app.delete("/pricing-packages/:packageId", async (req, res, next) => {
  try {
    const pricing = await readPricingSettings();
    const packages = (pricing.pricingPackages || []).filter(
      (packagePreset) => packagePreset.id !== req.params.packageId,
    );
    if (packages.length === (pricing.pricingPackages || []).length) {
      return res.status(404).json({ error: "Pricing package not found" });
    }
    await pool.query(
      `INSERT INTO pricing_settings (id, data, updated_at)
       VALUES (1, $1::jsonb, NOW())
       ON CONFLICT (id) DO UPDATE SET data = EXCLUDED.data, updated_at = NOW()`,
      [JSON.stringify({ ...pricing, pricingPackages: packages })],
    );
    res.json(packages);
  } catch (error) {
    next(error);
  }
});

app.get("/estimates", async (req, res, next) => {
  try {
    const result = await pool.query(
      "SELECT estimate_id, job_id, data, created_at, updated_at FROM estimates ORDER BY updated_at DESC, estimate_id DESC",
    );
    res.json(
      result.rows.map((row) => ({
        ...row.data,
        estimate_id: row.estimate_id,
        job_id: row.job_id,
        created_at: row.created_at,
        updated_at: row.updated_at,
      })),
    );
  } catch (error) {
    next(error);
  }
});

app.post("/estimates", async (req, res, next) => {
  try {
    const { job_id: jobId = null, ...incomingData } = req.body || {};
    if (!incomingData.customerName || !incomingData.address || !incomingData.measurements?.squares) {
      return res.status(400).json({
        error: "customerName, address, and measurements.squares are required",
      });
    }
    incomingData.status = incomingData.status || "Draft";
    if (!validEstimateStatus(incomingData.status)) {
      return res.status(400).json({ error: "Invalid estimate status" });
    }
    const data = await calculateEstimateData(incomingData);
    const result = await pool.query(
      "INSERT INTO estimates (job_id, data) VALUES ($1, $2::jsonb) RETURNING estimate_id, job_id, data, created_at, updated_at",
      [jobId, JSON.stringify(data)],
    );
    const row = result.rows[0];
    res.status(201).json({
      ...row.data,
      estimate_id: row.estimate_id,
      job_id: row.job_id,
      created_at: row.created_at,
      updated_at: row.updated_at,
    });
  } catch (error) {
    next(error);
  }
});

app.put("/estimates/:estimateId", async (req, res, next) => {
  try {
    const estimateId = Number(req.params.estimateId);
    if (!Number.isInteger(estimateId)) {
      return res.status(400).json({ error: "Invalid estimate ID" });
    }
    const { job_id: jobId = null, ...incomingData } = req.body || {};
    incomingData.status = incomingData.status || "Draft";
    if (!validEstimateStatus(incomingData.status)) {
      return res.status(400).json({ error: "Invalid estimate status" });
    }
    const data = await calculateEstimateData(incomingData);
    const result = await pool.query(
      `UPDATE estimates
       SET job_id = $1, data = $2::jsonb, updated_at = NOW()
       WHERE estimate_id = $3
       RETURNING estimate_id, job_id, data, created_at, updated_at`,
      [jobId, JSON.stringify(data), estimateId],
    );
    if (!result.rows[0]) return res.status(404).json({ error: "Estimate not found" });
    const row = result.rows[0];
    res.json({
      ...row.data,
      estimate_id: row.estimate_id,
      job_id: row.job_id,
      created_at: row.created_at,
      updated_at: row.updated_at,
    });
  } catch (error) {
    next(error);
  }
});

app.patch("/estimates/:estimateId/status", async (req, res, next) => {
  try {
    const estimateId = Number(req.params.estimateId);
    const status = req.body?.status;
    if (!Number.isInteger(estimateId)) {
      return res.status(400).json({ error: "Invalid estimate ID" });
    }
    if (!validEstimateStatus(status)) {
      return res.status(400).json({ error: "Invalid estimate status" });
    }
    const result = await pool.query(
      `UPDATE estimates
       SET data = jsonb_set(data, '{status}', to_jsonb($1::text)), updated_at = NOW()
       WHERE estimate_id = $2
       RETURNING estimate_id, job_id, data, created_at, updated_at`,
      [status, estimateId],
    );
    if (!result.rows[0]) return res.status(404).json({ error: "Estimate not found" });
    const row = result.rows[0];
    res.json({
      ...row.data,
      estimate_id: row.estimate_id,
      job_id: row.job_id,
      created_at: row.created_at,
      updated_at: row.updated_at,
    });
  } catch (error) {
    next(error);
  }
});

app.delete("/estimates/:estimateId", async (req, res, next) => {
  const estimateId = Number(req.params.estimateId);
  if (!Number.isInteger(estimateId)) {
    return res.status(400).json({ error: "Invalid estimate ID" });
  }
  if (!validAdminPassword(req.body?.password)) {
    return res.status(403).json({ error: "Administrator password is incorrect" });
  }
  try {
    const result = await pool.query(
      "DELETE FROM estimates WHERE estimate_id = $1 RETURNING estimate_id",
      [estimateId],
    );
    if (!result.rowCount) return res.status(404).json({ error: "Estimate not found" });
    res.json({ deleted: true, estimate_id: result.rows[0].estimate_id });
  } catch (error) {
    next(error);
  }
});

app.get("/estimates/:estimateId/documents", async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT document_id, name, content_type AS type, size_bytes AS size, created_at
       FROM estimate_documents WHERE estimate_id = $1 ORDER BY created_at DESC`,
      [req.params.estimateId],
    );
    res.json(result.rows);
  } catch (error) {
    next(error);
  }
});

app.post("/estimates/:estimateId/documents", async (req, res, next) => {
  try {
    const { name, type = "application/octet-stream", size, content } = req.body || {};
    const estimateId = Number(req.params.estimateId);
    if (!Number.isInteger(estimateId) || !name?.trim() || !content) {
      return res.status(400).json({ error: "A valid estimate and file are required" });
    }
    const file = Buffer.from(content, "base64");
    if (!file.length || file.length > 10 * 1024 * 1024 || Number(size) !== file.length) {
      return res.status(400).json({ error: "Files must be no larger than 10 MB" });
    }
    const result = await pool.query(
      `INSERT INTO estimate_documents (estimate_id, name, content_type, size_bytes, content)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING document_id, name, content_type AS type, size_bytes AS size, created_at`,
      [estimateId, name.trim().slice(0, 255), String(type).slice(0, 150), file.length, file],
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    if (error.code === "23503") return res.status(404).json({ error: "Estimate not found" });
    next(error);
  }
});

app.get("/estimates/:estimateId/documents/:documentId/download", async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT name, content_type, content FROM estimate_documents
       WHERE estimate_id = $1 AND document_id = $2`,
      [req.params.estimateId, req.params.documentId],
    );
    const document = result.rows[0];
    if (!document) return res.status(404).json({ error: "Document not found" });
    res.setHeader("Content-Type", document.content_type);
    res.setHeader("Content-Disposition", `attachment; filename*=UTF-8''${encodeURIComponent(document.name)}`);
    res.send(document.content);
  } catch (error) {
    next(error);
  }
});

app.delete("/estimates/:estimateId/documents/:documentId", async (req, res, next) => {
  try {
    const result = await pool.query(
      "DELETE FROM estimate_documents WHERE estimate_id = $1 AND document_id = $2 RETURNING document_id",
      [req.params.estimateId, req.params.documentId],
    );
    if (!result.rows[0]) return res.status(404).json({ error: "Document not found" });
    res.json({ deleted: true });
  } catch (error) {
    next(error);
  }
});

app.post("/estimates/:estimateId/document-packet", async (req, res, next) => {
  try {
    const estimateId = Number(req.params.estimateId);
    const format = req.body?.format;
    const documentIds = [...new Set((req.body?.documentIds || []).map(Number))]
      .filter(Number.isInteger);
    if (!Number.isInteger(estimateId) || !documentIds.length || !["zip", "pdf"].includes(format)) {
      return res.status(400).json({ error: "Select at least one document and a valid packet format" });
    }

    const result = await pool.query(
      `SELECT document_id, name, content_type, content
       FROM estimate_documents
       WHERE estimate_id = $1 AND document_id = ANY($2::bigint[])`,
      [estimateId, documentIds],
    );
    const byId = new Map(result.rows.map((document) => [Number(document.document_id), document]));
    const documents = documentIds.map((id) => byId.get(id)).filter(Boolean);
    if (documents.length !== documentIds.length) {
      return res.status(404).json({ error: "One or more selected documents were not found" });
    }

    const filename = `estimate-${estimateId}-customer-packet.${format}`;
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);

    if (format === "zip") {
      res.setHeader("Content-Type", "application/zip");
      const archive = new ZipArchive({ zlib: { level: 9 } });
      archive.on("error", next);
      archive.pipe(res);
      documents.forEach((document) => archive.append(document.content, { name: document.name }));
      await archive.finalize();
      return;
    }

    const unsupported = documents.filter((document) =>
      !["application/pdf", "image/jpeg", "image/png"].includes(document.content_type));
    if (unsupported.length) {
      return res.status(400).json({
        error: `PDF packets support PDF, JPG, and PNG files. Use ZIP for: ${unsupported.map((item) => item.name).join(", ")}`,
      });
    }

    const packet = await PDFDocument.create();
    for (const document of documents) {
      if (document.content_type === "application/pdf") {
        const source = await PDFDocument.load(document.content);
        const pages = await packet.copyPages(source, source.getPageIndices());
        pages.forEach((page) => packet.addPage(page));
      } else {
        const image = document.content_type === "image/png"
          ? await packet.embedPng(document.content)
          : await packet.embedJpg(document.content);
        const pageWidth = 612;
        const pageHeight = 792;
        const scale = Math.min((pageWidth - 72) / image.width, (pageHeight - 72) / image.height, 1);
        const width = image.width * scale;
        const height = image.height * scale;
        const page = packet.addPage([pageWidth, pageHeight]);
        page.drawImage(image, {
          x: (pageWidth - width) / 2,
          y: (pageHeight - height) / 2,
          width,
          height,
        });
      }
    }
    res.setHeader("Content-Type", "application/pdf");
    res.send(Buffer.from(await packet.save()));
  } catch (error) {
    next(error);
  }
});

app.use((error, req, res, next) => {
  console.error(error);
  const status = error.statusCode === 400 ? 400 : 500;
  res.status(status).json({
    error: status === 400 ? error.message : "Unable to access saved jobs",
  });
});

// Serve the built React app for everything else
const buildDir = path.join(__dirname, "build");
app.use(express.static(buildDir));
app.get("/{*splat}", (req, res) => {
  res.sendFile(path.join(buildDir, "index.html"));
});

if (require.main === module) {
  const PORT = process.env.PORT || 3000;
  Promise.all([
    pool.query(
      `CREATE TABLE IF NOT EXISTS estimate_documents (
        document_id BIGSERIAL PRIMARY KEY,
        estimate_id INTEGER NOT NULL REFERENCES estimates(estimate_id) ON DELETE CASCADE,
        name TEXT NOT NULL,
        content_type TEXT NOT NULL,
        size_bytes INTEGER NOT NULL,
        content BYTEA NOT NULL,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )`,
    ),
    pool.query(
      `CREATE TABLE IF NOT EXISTS leads (
        id SERIAL PRIMARY KEY,
        name TEXT,
        phone TEXT,
        email TEXT,
        service_type TEXT,
        address TEXT
      )`,
    ),
  ]).then(() => {
    app.listen(PORT, "0.0.0.0", () => console.log(`Roofing app running on 0.0.0.0:${PORT}`));
  }).catch((error) => {
    console.error("Unable to initialize database tables", error);
    process.exit(1);
  });
}

module.exports = { app, calculateEstimateData, validEstimateStatus };
