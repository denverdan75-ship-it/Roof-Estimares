export const ESTIMATE_STATUSES = ["Draft", "Sent", "Approved", "Scheduled", "Completed", "Declined"];
