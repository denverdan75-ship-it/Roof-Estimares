function numberOrZero(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number : 0;
}

export function calculateMeasurements(inputValue, inputUnit = "squares", wastePercent = 0) {
  const normalizedInputValue = Math.max(0, numberOrZero(inputValue));
  const baseSqFt = inputUnit === "sqft" ? normalizedInputValue : normalizedInputValue * 100;
  const baseSquares = baseSqFt / 100;
  const normalizedWastePercent = Math.max(0, numberOrZero(wastePercent));
  const squares = baseSquares * (1 + normalizedWastePercent / 100);

  return {
    inputValue: normalizedInputValue,
    inputUnit,
    baseSqFt,
    baseSquares,
    squares,
    wastePercent: normalizedWastePercent,
  };
}

export function calculatePricedLineItems(lineItems = [], measurements) {
  return lineItems.map((item) => {
    const quantity = item.unit === "square"
      ? measurements.squares
      : item.unit === "sqft"
        ? measurements.baseSqFt
        : numberOrZero(item.quantity);
    const rate = numberOrZero(item.rate);

    return { ...item, quantity, rate, total: quantity * rate };
  });
}

export function calculateTotals(pricedLineItems = [], pricing = {}) {
  const subtotal = pricedLineItems.reduce((sum, item) => sum + numberOrZero(item.total), 0);
  const overhead = subtotal * (numberOrZero(pricing.overheadPercent) / 100);
  const markedUp = (subtotal + overhead) * (numberOrZero(pricing.markupPercent) / 100);
  const taxable = subtotal + overhead + markedUp;
  const tax = taxable * (numberOrZero(pricing.taxPercent) / 100);

  return { subtotal, overhead, markedUp, tax, total: taxable + tax };
}