import React, { useEffect, useMemo, useState } from "react";
import { listEstimates, listLeads, updateEstimateStatus } from "../api/client";
import { ESTIMATE_STATUSES } from "../estimateStatuses";
import { trackEvent } from "../analytics";
import "./JobDashboard.css";

const money = (value) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(value || 0);

const shortDate = (value) =>
  value ? new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric" }).format(new Date(value)) : "—";

export default function JobDashboard({ refreshKey, onNewEstimate, onConvertLead, onOpenEstimate, onPreview }) {
  const [estimates, setEstimates] = useState([]);
  const [leads, setLeads] = useState([]);
  const [status, setStatus] = useState("loading");
  const [activeTab, setActiveTab] = useState("leads");
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [updatingId, setUpdatingId] = useState(null);
  const [updateError, setUpdateError] = useState("");

  useEffect(() => {
    let active = true;
    setStatus("loading");
    Promise.all([listEstimates(), listLeads()])
      .then(([estimateData, leadData]) => {
        if (!active) return;
        setEstimates(estimateData);
        setLeads(leadData);
        setStatus("ready");
      })
      .catch(() => active && setStatus("error"));
    return () => { active = false; };
  }, [refreshKey]);

  const statuses = ["All", ...ESTIMATE_STATUSES];

  const changeStatus = async (estimate, nextStatus) => {
    const previousStatus = estimate.status || "Draft";
    if (nextStatus === previousStatus) return;
    setUpdatingId(estimate.estimate_id);
    setUpdateError("");
    setEstimates((current) => current.map((item) => (
      item.estimate_id === estimate.estimate_id ? { ...item, status: nextStatus } : item
    )));
    try {
      const saved = await updateEstimateStatus(estimate.estimate_id, nextStatus);
      trackEvent("job_status_changed", {
        from_status: previousStatus,
        to_status: nextStatus,
      });
      setEstimates((current) => current.map((item) => (
        item.estimate_id === saved.estimate_id ? saved : item
      )));
    } catch (error) {
      setEstimates((current) => current.map((item) => (
        item.estimate_id === estimate.estimate_id ? { ...item, status: previousStatus } : item
      )));
      setUpdateError(error.message);
    } finally {
      setUpdatingId(null);
    }
  };

  const visible = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return estimates.filter((estimate) => {
      const matchesStatus = statusFilter === "All" || (estimate.status || "Draft") === statusFilter;
      const matchesQuery = !needle || [estimate.customerName, estimate.address, estimate.estimate_id]
        .some((value) => String(value || "").toLowerCase().includes(needle));
      return matchesStatus && matchesQuery;
    });
  }, [estimates, query, statusFilter]);

  const pipelineValue = estimates.reduce((sum, estimate) => sum + Number(estimate.totals?.total || 0), 0);
  const customerCount = new Set(estimates.map((estimate) => estimate.customerName?.trim().toLowerCase()).filter(Boolean)).size;
  const draftCount = estimates.filter((estimate) => (estimate.status || "Draft") === "Draft").length;
  const activeCount = estimates.filter((estimate) => !["Completed", "Declined"].includes(estimate.status || "Draft")).length;

  return (
    <main className="dashboard">
      <section className="dashboard__intro">
        <div>
          <p className="eyebrow">Operations overview</p>
          <h2>Customer &amp; job dashboard</h2>
          <p>Track active opportunities, find customer work, and move directly into estimating.</p>
        </div>
        <button className="dashboard__primary" type="button" onClick={onNewEstimate}>New estimate</button>
      </section>

      <section className="dashboard__metrics" aria-label="Business summary">
        <article><span>Total pipeline</span><strong>{money(pipelineValue)}</strong><small>Across all saved estimates</small></article>
        <article><span>Active jobs</span><strong>{activeCount}</strong><small>Excludes completed and declined work</small></article>
        <article><span>New leads</span><strong>{leads.length}</strong><small>Customer intake submissions</small></article>
        <article><span>Drafts</span><strong>{draftCount}</strong><small>Waiting to be completed</small></article>
      </section>

      <section className="dashboard__work">
        <div className="dashboard__tabs" role="tablist" aria-label="Dashboard sections">
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === "leads"}
            className={activeTab === "leads" ? "is-active" : ""}
            onClick={() => setActiveTab("leads")}
          >
            New Leads <span>{leads.length}</span>
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === "jobs"}
            className={activeTab === "jobs" ? "is-active" : ""}
            onClick={() => setActiveTab("jobs")}
          >
            Customers &amp; Jobs <span>{customerCount}</span>
          </button>
        </div>

        {activeTab === "leads" && (
          <>
            <div className="dashboard__work-header">
              <div>
                <p className="eyebrow">Customer intake</p>
                <h3>New leads</h3>
              </div>
              <p className="dashboard__section-note">Newest submissions appear first.</p>
            </div>
            {status === "loading" && <p className="dashboard__state">Loading new leads…</p>}
            {status === "error" && <p className="dashboard__state dashboard__state--error">New leads could not be loaded.</p>}
            {status === "ready" && leads.length === 0 && (
              <div className="dashboard__empty">
                <strong>No customer intake submissions yet.</strong>
                <p>New customer information will be filed here automatically.</p>
              </div>
            )}
            {status === "ready" && leads.length > 0 && (
              <div className="dashboard__table-wrap">
                <table className="dashboard__table">
                  <thead><tr><th>Customer</th><th>Contact</th><th>Property</th><th>Service</th><th><span className="sr-only">Actions</span></th></tr></thead>
                  <tbody>
                    {leads.map((lead) => (
                      <tr key={lead.id}>
                        <td><strong>{lead.name}</strong><small>Lead #{lead.id}</small></td>
                        <td><strong>{lead.phone || "No phone"}</strong><small>{lead.email || "No email"}</small></td>
                        <td>{lead.address || "Address not provided"}</td>
                        <td>{lead.service_type || "Roofing inquiry"}</td>
                        <td>
                          <div className="dashboard__row-actions">
                            <button
                              className="dashboard__convert"
                              type="button"
                              onClick={() => onConvertLead(lead)}
                              aria-label={`Convert ${lead.name} to the estimator`}
                            >
                              Convert to Estimator
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </>
        )}

        {activeTab === "jobs" && (
          <>
        <div className="dashboard__work-header">
          <div>
            <p className="eyebrow">Current pipeline</p>
            <h3>Customers and jobs</h3>
          </div>
          <div className="dashboard__filters">
            <label>
              <span className="sr-only">Search customers and jobs</span>
              <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search name, address, or #" />
            </label>
            <label>
              <span className="sr-only">Filter by status</span>
              <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
                {statuses.map((item) => <option key={item}>{item}</option>)}
              </select>
            </label>
          </div>
        </div>

        {status === "loading" && <p className="dashboard__state">Loading customer work…</p>}
        {status === "error" && <p className="dashboard__state dashboard__state--error">Customer work could not be loaded.</p>}
        {updateError && <p className="dashboard__update-error" role="alert">Status could not be saved. {updateError}</p>}
        {status === "ready" && estimates.length === 0 && (
          <div className="dashboard__empty">
            <strong>Your pipeline starts here.</strong>
            <p>Create the first estimate to add a customer and job to this dashboard.</p>
            <button type="button" onClick={onNewEstimate}>Create first estimate</button>
          </div>
        )}
        {status === "ready" && estimates.length > 0 && visible.length === 0 && (
          <p className="dashboard__state">No jobs match this search.</p>
        )}
        {status === "ready" && visible.length > 0 && (
          <div className="dashboard__table-wrap">
            <table className="dashboard__table">
              <thead><tr><th>Customer / property</th><th>Status</th><th>Roof</th><th>Estimate</th><th>Updated</th><th><span className="sr-only">Actions</span></th></tr></thead>
              <tbody>
                {visible.map((estimate) => (
                  <tr key={estimate.estimate_id}>
                    <td><strong>{estimate.customerName}</strong><small>{estimate.address}</small></td>
                    <td>
                      <select
                        className="dashboard__status"
                        aria-label={`Status for ${estimate.customerName}`}
                        value={estimate.status || "Draft"}
                        disabled={updatingId === estimate.estimate_id}
                        onChange={(event) => changeStatus(estimate, event.target.value)}
                      >
                        {ESTIMATE_STATUSES.map((item) => <option key={item} value={item}>{item}</option>)}
                      </select>
                    </td>
                    <td>{Number(estimate.measurements?.squares || 0).toFixed(2)} sq.</td>
                    <td><strong>{money(estimate.totals?.total)}</strong><small>#{estimate.estimate_id}</small></td>
                    <td>{shortDate(estimate.updated_at || estimate.created_at)}</td>
                    <td>
                      <div className="dashboard__row-actions">
                        <button type="button" onClick={() => onOpenEstimate(estimate)}>Open</button>
                        <button type="button" onClick={() => onPreview(estimate)}>Proposal</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
          </>
        )}
      </section>
    </main>
  );
}