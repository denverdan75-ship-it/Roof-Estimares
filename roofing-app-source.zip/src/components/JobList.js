import React, { useCallback, useEffect, useState } from "react";
import { listJobs } from "../api/client";
import "./JobList.css";

export default function JobList({ refreshKey }) {
  const [jobs, setJobs] = useState([]);
  const [status, setStatus] = useState("loading"); // loading | ready | error
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    setStatus("loading");
    try {
      const data = await listJobs();
      setJobs(Array.isArray(data) ? data : []);
      setStatus("ready");
    } catch (err) {
      setError(err.message);
      setStatus("error");
    }
  }, []);

  useEffect(() => {
    load();
  }, [load, refreshKey]);

  return (
    <div className="job-list">
      <div className="job-list__header">
        <h2 className="job-list__title">Jobs</h2>
        <button className="job-list__refresh" onClick={load} type="button">
          Refresh
        </button>
      </div>

      {status === "loading" && <p className="job-list__note">Loading jobs…</p>}

      {status === "error" && (
        <p className="job-list__note job-list__note--error">Couldn't load jobs: {error}</p>
      )}

      {status === "ready" && jobs.length === 0 && (
        <p className="job-list__note">No jobs yet. Submit one on the left to see it here.</p>
      )}

      {status === "ready" && jobs.length > 0 && (
        <ul className="job-list__items">
          {jobs.map((job) => (
            <li className="job-list__item" key={job.job_id}>
              <span className="job-list__item-id">#{job.job_id}</span>
              <span className="job-list__item-address">{job.payload?.address}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
