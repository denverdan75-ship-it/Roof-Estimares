import React, { useEffect, useMemo, useRef, useState } from "react";
import EstimateDocuments from "./EstimateDocuments";
import {
  createEstimate,
  createPricingPackage,
  createPricingPreset,
  deletePricingPackage,
  deletePricingPreset,
  getPricingSettings,
  listPricingPackages,
  listPricingPresets,
  savePricingSettings,
  updateEstimate,
  updatePricingPackage,
  updatePricingPreset,
} from "../api/client";
import { trackEvent } from "../analytics";
import { calculateMeasurements, calculatePricedLineItems, calculateTotals } from "../calculations.mjs";
import { ESTIMATE_STATUSES } from "../estimateStatuses";
import "./EstimateForm.css";

const fallbackPricing = {
  materialPerSquare: 145,
  laborPerSquare: 85,
  tearOffPerSquare: 45,
  disposalFee: 350,
  overheadPercent: 10,
  markupPercent: 20,
  taxPercent: 0,
};

const fallbackPresets = [
  { id: "roofing-materials", name: "Roofing materials", category: "material", unit: "square", rate: 145 },
  { id: "installation-labor", name: "Installation labor", category: "service", unit: "square", rate: 85 },
  { id: "tear-off", name: "Tear-off", category: "service", unit: "square", rate: 45 },
  { id: "disposal-delivery", name: "Disposal and delivery", category: "service", unit: "flat", rate: 350 },
];

const emptyForm = {
  customerName: "",
  phone: "",
  email: "",
  address: "",
  areaMode: "squares",
  areaValue: "",
  wastePercent: 10,
};

const emptyProposal = {
  companyName: "",
  companyPhone: "",
  companyEmail: "",
  companyAddress: "",
  companyWebsite: "dragonflyroofingcompany.com",
  companyFacebook: "https://www.facebook.com/DragonflyRoofingCompany",
  companyInstagram: "https://www.instagram.com/dragonfly_roofing_co?stkn=Z2NwZDgzZ3gwZHI0",
  scopeOfWork: "Remove existing roofing and install the selected roofing system.",
  exclusions: "Decking replacement, structural repairs, and concealed damage are excluded unless listed above.",
  terms: "Estimate valid for 30 days. Work begins after signed approval and deposit.",
};

const emptyPreset = { id: null, name: "", category: "material", unit: "square", rate: "" };
const emptyPackage = { id: null, name: "", presetIds: [] };
const emptyBlueprint = { length: "", width: "", pitch: "6", ridgeDirection: "horizontal", notes: "" };
const unitOptions = [
  ["square", "square"],
  ["sqft", "sq. ft."],
  ["each", "each"],
  ["linear-foot", "linear ft."],
  ["hour", "hour"],
  ["flat", "flat"],
];

const money = (value) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(value || 0);

const makeId = (prefix) => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

function normalizeItem(item, index) {
  return {
    id: item.id || makeId(`item-${index}`),
    presetId: item.presetId || null,
    name: item.name || "Custom line item",
    category: item.category === "service" ? "service" : "material",
    unit: item.unit || "flat",
    quantity: item.quantity ?? 1,
    rate: item.rate ?? 0,
  };
}

function itemsFromPresets(presetList) {
  return presetList.map((preset, index) => normalizeItem({
    ...preset,
    presetId: preset.id,
    quantity: 1,
  }, index));
}

function unitLabel(unit) {
  return unitOptions.find(([value]) => value === unit)?.[1] || unit;
}

export default function EstimateForm({ initialEstimate, onEstimateSaved, onCancel }) {
  const [form, setForm] = useState(emptyForm);
  const [proposal, setProposal] = useState(emptyProposal);
  const [pricing, setPricing] = useState(fallbackPricing);
  const [presets, setPresets] = useState(fallbackPresets);
  const [packages, setPackages] = useState([]);
  const presetsRef = useRef(fallbackPresets);
  const [lineItems, setLineItems] = useState(() => itemsFromPresets(fallbackPresets));
  const [presetDraft, setPresetDraft] = useState(emptyPreset);
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState("");
  const [presetStatus, setPresetStatus] = useState("idle");
  const [presetError, setPresetError] = useState("");
  const [blueprint, setBlueprint] = useState(emptyBlueprint);
  const [packageDraft, setPackageDraft] = useState(emptyPackage);
  const [packageStatus, setPackageStatus] = useState("idle");
  const [packageError, setPackageError] = useState("");
  const [estimateStatus, setEstimateStatus] = useState("Draft");

  useEffect(() => {
    presetsRef.current = presets;
  }, [presets]);

  useEffect(() => {
    let active = true;
    Promise.all([getPricingSettings(), listPricingPresets(), listPricingPackages()])
      .then(([settings, savedPresets, savedPackages]) => {
        if (!active) return;
        const nextPricing = { ...fallbackPricing, ...(settings || {}) };
        const nextPresets = savedPresets?.length ? savedPresets : (settings?.lineItemPresets || fallbackPresets);
        const nextPackages = savedPackages?.length ? savedPackages : (settings?.pricingPackages || []);
        setPricing(nextPricing);
        setPresets(nextPresets);
        setPackages(nextPackages);
        if (!initialEstimate) setProposal({ ...emptyProposal, ...(nextPricing.companyDefaults || {}) });
        if (!initialEstimate) setLineItems(itemsFromPresets(nextPresets));
      })
      .catch(() => {
        if (active) {
          setPricing(fallbackPricing);
          setPresets(fallbackPresets);
          setPackages([]);
          if (!initialEstimate) setProposal(emptyProposal);
          if (!initialEstimate) setLineItems(itemsFromPresets(fallbackPresets));
        }
      });
    return () => { active = false; };
  }, [initialEstimate]);

  useEffect(() => {
    if (!initialEstimate) {
      setForm(emptyForm);
      setEstimateStatus("Draft");
      setPricing((current) => ({ ...fallbackPricing, ...current }));
      setLineItems(itemsFromPresets(presetsRef.current));
      setBlueprint(emptyBlueprint);
      return;
    }
    setForm({
      customerName: initialEstimate.customerName || "",
      phone: initialEstimate.phone || "",
      email: initialEstimate.email || "",
      address: initialEstimate.address || "",
      areaMode: initialEstimate.measurements?.inputUnit || "squares",
      areaValue: initialEstimate.measurements?.inputValue || "",
      wastePercent: initialEstimate.measurements?.wastePercent ?? 10,
    });
    setEstimateStatus(initialEstimate.status || "Draft");
      setProposal({ ...emptyProposal, ...(initialEstimate.proposal || {}) });
    setPricing({ ...fallbackPricing, ...(initialEstimate.pricing || {}) });
    setLineItems(
      (initialEstimate.lineItems?.length ? initialEstimate.lineItems : itemsFromPresets(presetsRef.current))
        .map(normalizeItem),
    );
    setBlueprint({ ...emptyBlueprint, ...(initialEstimate.blueprint || {}) });
  }, [initialEstimate]);

  const measurements = useMemo(
    () => calculateMeasurements(form.areaValue, form.areaMode, form.wastePercent),
    [form.areaValue, form.areaMode, form.wastePercent],
  );

  const pricedLineItems = useMemo(
    () => calculatePricedLineItems(lineItems, measurements),
    [lineItems, measurements],
  );

  const totals = useMemo(
    () => calculateTotals(pricedLineItems, pricing),
    [pricedLineItems, pricing],
  );

  const changeForm = (event) => {
    const { name, value } = event.target;
    setForm((current) => ({ ...current, [name]: value }));
  };

  const changePricing = (event) => {
    const { name, value } = event.target;
    setPricing((current) => ({ ...current, [name]: value }));
  };

  const changeProposal = (event) => {
    const { name, value } = event.target;
    setProposal((current) => ({ ...current, [name]: value }));
  };

  const updateLineItem = (id, field, value) => {
    setLineItems((current) => current.map((item) => (item.id === id ? { ...item, [field]: value } : item)));
  };

  const addLineItem = (preset = null) => {
    const item = preset
      ? { ...preset, presetId: preset.id, quantity: preset.unit === "flat" ? 1 : 1 }
      : { name: "New line item", category: "material", unit: "flat", quantity: 1, rate: 0 };
    setLineItems((current) => [...current, normalizeItem({ ...item, id: makeId("item") }, current.length)]);
  };

  const addPackage = (savedPackage) => {
    const packagePresets = (savedPackage.presetIds || [])
      .map((presetId) => presets.find((preset) => preset.id === presetId))
      .filter(Boolean);
    if (!packagePresets.length) return;
    setLineItems((current) => [
      ...current,
      ...packagePresets.map((preset, index) => normalizeItem({
        ...preset,
        id: makeId("item"),
        presetId: preset.id,
        quantity: 1,
      }, current.length + index)),
    ]);
  };

  const removeLineItem = (id) => {
    setLineItems((current) => current.filter((item) => item.id !== id));
  };

  const moveLineItem = (index, direction) => {
    setLineItems((current) => {
      const nextIndex = index + direction;
      if (nextIndex < 0 || nextIndex >= current.length) return current;
      const next = [...current];
      [next[index], next[nextIndex]] = [next[nextIndex], next[index]];
      return next;
    });
  };

  const editPreset = (preset) => {
    setPresetDraft({ ...preset, rate: String(preset.rate) });
    setPresetError("");
  };

  const savePreset = async (event) => {
    event.preventDefault();
    if (!presetDraft.name.trim() || presetDraft.rate === "" || Number(presetDraft.rate) < 0) {
      setPresetStatus("error");
      setPresetError("Preset name and a non-negative rate are required.");
      return;
    }
    setPresetStatus("saving");
    setPresetError("");
    const payload = { ...presetDraft, name: presetDraft.name.trim(), rate: Number(presetDraft.rate) };
    try {
      const saved = presetDraft.id
        ? await updatePricingPreset(presetDraft.id, payload)
        : await createPricingPreset(payload);
      setPresets((current) => {
        const next = presetDraft.id
          ? current.map((preset) => (preset.id === saved.id ? saved : preset))
          : [...current, saved];
        presetsRef.current = next;
        return next;
      });
      setPresetDraft(emptyPreset);
      setPresetStatus("success");
    } catch (err) {
      setPresetStatus("error");
      setPresetError(err.message);
    }
  };

  const deletePreset = async (id) => {
    setPresetStatus("saving");
    setPresetError("");
    try {
      const remaining = await deletePricingPreset(id);
      setPresets(remaining);
      presetsRef.current = remaining;
      setPackages((current) => current.map((savedPackage) => ({
        ...savedPackage,
        presetIds: (savedPackage.presetIds || []).filter((presetId) => presetId !== id),
      })));
      setPresetDraft((current) => (current.id === id ? emptyPreset : current));
      setPresetStatus("success");
    } catch (err) {
      setPresetStatus("error");
      setPresetError(err.message);
    }
  };

  const editPackage = (savedPackage) => {
    setPackageDraft({
      id: savedPackage.id,
      name: savedPackage.name,
      presetIds: [...(savedPackage.presetIds || [])],
    });
    setPackageError("");
  };

  const addPresetToPackage = (presetId) => {
    setPackageDraft((current) => (
      current.presetIds.includes(presetId)
        ? current
        : { ...current, presetIds: [...current.presetIds, presetId] }
    ));
  };

  const removePresetFromPackage = (presetId) => {
    setPackageDraft((current) => ({
      ...current,
      presetIds: current.presetIds.filter((id) => id !== presetId),
    }));
  };

  const movePackagePreset = (index, direction) => {
    setPackageDraft((current) => {
      const nextIndex = index + direction;
      if (nextIndex < 0 || nextIndex >= current.presetIds.length) return current;
      const presetIds = [...current.presetIds];
      [presetIds[index], presetIds[nextIndex]] = [presetIds[nextIndex], presetIds[index]];
      return { ...current, presetIds };
    });
  };

  const savePackage = async (event) => {
    event.preventDefault();
    if (!packageDraft.name.trim() || !packageDraft.presetIds.length) {
      setPackageStatus("error");
      setPackageError("Package name and at least one saved material or service are required.");
      return;
    }
    setPackageStatus("saving");
    setPackageError("");
    const payload = {
      name: packageDraft.name.trim(),
      presetIds: packageDraft.presetIds,
    };
    try {
      const saved = packageDraft.id
        ? await updatePricingPackage(packageDraft.id, payload)
        : await createPricingPackage(payload);
      setPackages((current) => (
        packageDraft.id
          ? current.map((savedPackage) => (savedPackage.id === saved.id ? saved : savedPackage))
          : [...current, saved]
      ));
      setPackageDraft(emptyPackage);
      setPackageStatus("success");
    } catch (err) {
      setPackageStatus("error");
      setPackageError(err.message);
    }
  };

  const deletePackage = async (id) => {
    setPackageStatus("saving");
    setPackageError("");
    try {
      const remaining = await deletePricingPackage(id);
      setPackages(remaining);
      setPackageDraft((current) => (current.id === id ? emptyPackage : current));
      setPackageStatus("success");
    } catch (err) {
      setPackageStatus("error");
      setPackageError(err.message);
    }
  };

  const saveDefaults = async () => {
    setPresetStatus("saving");
    setPresetError("");
    try {
      await savePricingSettings({
        materialPerSquare: Number(pricing.materialPerSquare) || 0,
        laborPerSquare: Number(pricing.laborPerSquare) || 0,
        tearOffPerSquare: Number(pricing.tearOffPerSquare) || 0,
        disposalFee: Number(pricing.disposalFee) || 0,
        overheadPercent: Number(pricing.overheadPercent) || 0,
        markupPercent: Number(pricing.markupPercent) || 0,
        taxPercent: Number(pricing.taxPercent) || 0,
        companyDefaults: {
          companyName: proposal.companyName.trim(),
          companyPhone: proposal.companyPhone.trim(),
          companyEmail: proposal.companyEmail.trim(),
          companyAddress: proposal.companyAddress.trim(),
          companyWebsite: proposal.companyWebsite.trim(),
          companyFacebook: proposal.companyFacebook.trim(),
          companyInstagram: proposal.companyInstagram.trim(),
        },
      });
      setPresetStatus("success");
    } catch (err) {
      setPresetStatus("error");
      setPresetError(err.message);
    }
  };

  const submit = async (event) => {
    event.preventDefault();
    if (!form.customerName.trim() || !form.address.trim() || !measurements.squares) {
      setStatus("error");
      setError("Customer name, address, and roof size are required.");
      return;
    }
    setStatus("saving");
    setError("");
    const estimate = {
      customerName: form.customerName.trim(),
      phone: form.phone.trim(),
      email: form.email.trim(),
      address: form.address.trim(),
      status: estimateStatus,
      measurements: { ...measurements, wastePercent: Number(form.wastePercent) || 0 },
      lineItems: pricedLineItems,
      pricing,
      proposal,
      blueprint,
      totals,
    };
    try {
      const isUpdate = Boolean(initialEstimate?.estimate_id);
      if (isUpdate) {
        await updateEstimate(initialEstimate.estimate_id, estimate);
      } else {
        await createEstimate(estimate);
      }
      trackEvent("estimate_saved", {
        action: isUpdate ? "updated" : "created",
        status: estimateStatus,
        input_unit: form.areaMode,
        line_item_count: pricedLineItems.length,
      });
      setStatus("success");
      onEstimateSaved?.();
    } catch (err) {
      setStatus("error");
      setError(err.message);
    }
  };

  return (
    <form className="estimate-form" onSubmit={submit}>
      <div className="estimate-form__heading">
        <div>
          <p className="eyebrow">Estimate workspace</p>
          <h2>{initialEstimate ? `Edit estimate #${initialEstimate.estimate_id}` : "New estimate"}</h2>
        </div>
        {initialEstimate && <button type="button" className="text-button" onClick={onCancel}>New estimate</button>}
      </div>

      <section className="estimate-form__section estimate-form__status-section">
        <div>
          <h3>Job status</h3>
          <p>Update the stage as this job moves through sales and production.</p>
        </div>
        <label>
          <span className="sr-only">Job status</span>
          <select value={estimateStatus} onChange={(event) => setEstimateStatus(event.target.value)}>
            {ESTIMATE_STATUSES.map((item) => <option key={item} value={item}>{item}</option>)}
          </select>
        </label>
      </section>

      <section className="estimate-form__section">
        <h3>Customer and property</h3>
        <div className="field-grid">
          <label><span>Customer name *</span><input name="customerName" value={form.customerName} onChange={changeForm} placeholder="Jordan Smith" /></label>
          <label><span>Phone</span><input name="phone" value={form.phone} onChange={changeForm} placeholder="(303) 555-0100" /></label>
          <label><span>Email</span><input name="email" type="email" value={form.email} onChange={changeForm} placeholder="jordan@example.com" /></label>
          <label className="field-grid__wide"><span>Property address *</span><input name="address" value={form.address} onChange={changeForm} placeholder="118 Birch St, Broomfield, CO" /></label>
        </div>
      </section>

      <section className="estimate-form__section">
        <h3>Roof measurements</h3>
        <div className="field-grid field-grid--measurements">
          <label><span>Enter measurement in</span><select name="areaMode" value={form.areaMode} onChange={changeForm}><option value="squares">Roofing squares</option><option value="sqft">Square feet</option></select></label>
          <label><span>{form.areaMode === "sqft" ? "Square feet" : "Roofing squares"} *</span><input name="areaValue" type="number" min="0" step="0.01" value={form.areaValue} onChange={changeForm} placeholder="24" /></label>
          <label><span>Waste allowance (%)</span><input name="wastePercent" type="number" min="0" max="100" step="0.5" value={form.wastePercent} onChange={changeForm} /></label>
        </div>
        <div className="conversion">
          <strong>{measurements.baseSqFt.toFixed(0)} sq. ft.</strong> base area
          <span>→</span>
          <strong>{measurements.squares.toFixed(2)} squares</strong> including waste
        </div>
      </section>

      <section className="estimate-form__section">
        <div className="section-heading"><div><h3>AI blueprint</h3><span>Generate a field-ready roof plan from manual dimensions.</span></div></div>
        <div className="blueprint-builder">
          <div className="field-grid field-grid--blueprint">
            <label><span>Building length (ft.)</span><input type="number" min="0" step="0.1" value={blueprint.length} onChange={(event) => setBlueprint((current) => ({ ...current, length: event.target.value }))} /></label>
            <label><span>Building width (ft.)</span><input type="number" min="0" step="0.1" value={blueprint.width} onChange={(event) => setBlueprint((current) => ({ ...current, width: event.target.value }))} /></label>
            <label><span>Roof pitch</span><select value={blueprint.pitch} onChange={(event) => setBlueprint((current) => ({ ...current, pitch: event.target.value }))}>{["2","3","4","5","6","7","8","9","10","12"].map((pitch) => <option key={pitch} value={pitch}>{pitch}:12</option>)}</select></label>
            <label><span>Ridge direction</span><select value={blueprint.ridgeDirection} onChange={(event) => setBlueprint((current) => ({ ...current, ridgeDirection: event.target.value }))}><option value="horizontal">Along building length</option><option value="vertical">Along building width</option></select></label>
          </div>
          <div className="blueprint-preview">
            <svg viewBox="0 0 480 260" role="img" aria-label="Generated roof blueprint">
              <rect x="55" y="35" width="370" height="190" />
              {blueprint.ridgeDirection === "horizontal"
                ? <><line x1="55" y1="130" x2="425" y2="130" /><line x1="55" y1="35" x2="240" y2="130" /><line x1="425" y1="35" x2="240" y2="130" /><line x1="55" y1="225" x2="240" y2="130" /><line x1="425" y1="225" x2="240" y2="130" /></>
                : <><line x1="240" y1="35" x2="240" y2="225" /><line x1="55" y1="35" x2="240" y2="130" /><line x1="425" y1="35" x2="240" y2="130" /><line x1="55" y1="225" x2="240" y2="130" /><line x1="425" y1="225" x2="240" y2="130" /></>}
              <text x="240" y="20" textAnchor="middle">{blueprint.length || "—"} ft. length</text>
              <text x="20" y="135" textAnchor="middle" transform="rotate(-90 20 135)">{blueprint.width || "—"} ft. width</text>
              <text x="240" y="252" textAnchor="middle">Pitch {blueprint.pitch}:12 · {measurements.squares.toFixed(2)} roofing squares</text>
            </svg>
          </div>
          <label className="blueprint-notes"><span>Blueprint notes</span><textarea rows="2" value={blueprint.notes} onChange={(event) => setBlueprint((current) => ({ ...current, notes: event.target.value }))} placeholder="Dormers, valleys, additions, access notes…" /></label>
          <p className="blueprint-disclaimer">Concept plan only. Verify all dimensions and roof geometry in the field before ordering materials.</p>
        </div>
      </section>

      <section className="estimate-form__section">
        <div className="section-heading"><div><h3>Documents</h3><span>Keep reports, photos, contracts, and supporting files with this estimate.</span></div></div>
        {initialEstimate?.estimate_id
          ? <EstimateDocuments estimateId={initialEstimate.estimate_id} />
          : <p className="document-box__locked">Save the draft estimate first, then reopen it to add documents.</p>}
      </section>

      <section className="estimate-form__section">
        <div className="section-heading"><div><h3>Proposal details</h3><span>These details appear on the customer-facing proposal.</span></div></div>
        <div className="field-grid">
          <label><span>Your company name</span><input name="companyName" value={proposal.companyName} onChange={changeProposal} placeholder="Summit Roofing LLC" /></label>
          <label><span>Company phone</span><input name="companyPhone" value={proposal.companyPhone} onChange={changeProposal} placeholder="(303) 555-0100" /></label>
          <label><span>Company email</span><input name="companyEmail" type="email" value={proposal.companyEmail} onChange={changeProposal} placeholder="estimates@summitroofing.com" /></label>
          <label><span>Company address</span><input name="companyAddress" value={proposal.companyAddress} onChange={changeProposal} placeholder="123 Main St, Denver, CO" /></label>
          <label className="field-grid__wide"><span>Company website</span><input name="companyWebsite" value={proposal.companyWebsite} onChange={changeProposal} placeholder="dragonflyroofingcompany.com" /></label>
          <label><span>Facebook profile</span><input name="companyFacebook" type="url" value={proposal.companyFacebook} onChange={changeProposal} placeholder="https://facebook.com/yourcompany" /></label>
          <label><span>Instagram profile</span><input name="companyInstagram" type="url" value={proposal.companyInstagram} onChange={changeProposal} placeholder="https://instagram.com/yourcompany" /></label>
          <label className="field-grid__wide"><span>Scope of work</span><textarea name="scopeOfWork" rows="3" value={proposal.scopeOfWork} onChange={changeProposal} /></label>
          <label className="field-grid__wide"><span>Exclusions and notes</span><textarea name="exclusions" rows="3" value={proposal.exclusions} onChange={changeProposal} /></label>
          <label className="field-grid__wide"><span>Terms and conditions</span><textarea name="terms" rows="3" value={proposal.terms} onChange={changeProposal} /></label>
        </div>
      </section>

      <section className="estimate-form__section">
        <div className="section-heading">
          <div><h3>Estimate line items</h3><span>Add materials and services, then adjust the rate for this estimate.</span></div>
          <button type="button" className="text-button text-button--accent" onClick={() => addLineItem()}>Add custom item</button>
        </div>
        <div className="line-items line-items--editable">
          {lineItems.length === 0 && <p className="empty-line-items">No line items yet. Add a material or service to build the estimate.</p>}
          {lineItems.map((item, index) => {
            const pricedItem = pricedLineItems[index];
            return (
              <div className="line-item line-item--editable" key={item.id}>
                <div className="line-item__fields">
                  <input className="line-item__name" aria-label="Line item name" value={item.name} onChange={(event) => updateLineItem(item.id, "name", event.target.value)} />
                  <select aria-label="Line item category" value={item.category} onChange={(event) => updateLineItem(item.id, "category", event.target.value)}>
                    <option value="material">Material</option>
                    <option value="service">Service</option>
                  </select>
                  <select aria-label="Line item unit" value={item.unit} onChange={(event) => updateLineItem(item.id, "unit", event.target.value)}>
                    {unitOptions.map(([value, label]) => <option value={value} key={value}>{label}</option>)}
                  </select>
                  {item.unit === "square" || item.unit === "sqft"
                    ? <span className="line-item__quantity">{pricedItem.quantity.toFixed(2)} {unitLabel(item.unit)}</span>
                    : <input aria-label="Line item quantity" className="line-item__quantity-input" type="number" min="0" step="0.01" value={item.quantity} onChange={(event) => updateLineItem(item.id, "quantity", event.target.value)} />}
                  <label className="line-item__rate"><span>Rate</span><input aria-label="Line item rate" type="number" min="0" step="0.01" value={item.rate} onChange={(event) => updateLineItem(item.id, "rate", event.target.value)} /></label>
                </div>
                <div className="line-item__summary">
                  <span>{pricedItem.quantity.toFixed(2)} {unitLabel(item.unit)} × {money(pricedItem.rate)}</span>
                  <strong>{money(pricedItem.total)}</strong>
                </div>
                <div className="line-item__actions">
                  <button type="button" className="icon-button" onClick={() => moveLineItem(index, -1)} disabled={index === 0} aria-label="Move line item up">↑</button>
                  <button type="button" className="icon-button" onClick={() => moveLineItem(index, 1)} disabled={index === lineItems.length - 1} aria-label="Move line item down">↓</button>
                  <button type="button" className="text-button" onClick={() => setPresetDraft({ id: null, name: item.name, category: item.category, unit: item.unit, rate: String(item.rate) })}>Save as preset</button>
                  <button type="button" className="text-button text-button--danger" onClick={() => removeLineItem(item.id)}>Remove</button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <section className="estimate-form__section">
        <div className="section-heading">
          <div><h3>Saved materials and services</h3><span>Reusable rates for future estimates.</span></div>
          <button type="button" className="text-button" onClick={() => setPresetDraft(emptyPreset)}>New preset</button>
        </div>
        <div className="preset-list">
          {presets.map((preset) => (
            <div className="preset-row" key={preset.id}>
              <div><strong>{preset.name}</strong><small>{preset.category} · {unitLabel(preset.unit)} · {money(preset.rate)}</small></div>
              <div className="preset-row__actions">
                <button type="button" className="text-button" onClick={() => addLineItem(preset)}>Use</button>
                <button type="button" className="text-button" onClick={() => editPreset(preset)}>Edit</button>
                <button type="button" className="text-button text-button--danger" onClick={() => deletePreset(preset.id)}>Delete</button>
              </div>
            </div>
          ))}
        </div>
        <div className="preset-editor">
          <p className="preset-editor__title">{presetDraft.id ? "Edit saved preset" : "Save a reusable preset"}</p>
          <div className="field-grid field-grid--preset">
            <label><span>Name</span><input value={presetDraft.name} onChange={(event) => setPresetDraft((current) => ({ ...current, name: event.target.value }))} placeholder="Synthetic shingles" /></label>
            <label><span>Type</span><select value={presetDraft.category} onChange={(event) => setPresetDraft((current) => ({ ...current, category: event.target.value }))}><option value="material">Material</option><option value="service">Service</option></select></label>
            <label><span>Unit</span><select value={presetDraft.unit} onChange={(event) => setPresetDraft((current) => ({ ...current, unit: event.target.value }))}>{unitOptions.map(([value, label]) => <option value={value} key={value}>{label}</option>)}</select></label>
            <label><span>Rate</span><input type="number" min="0" step="0.01" value={presetDraft.rate} onChange={(event) => setPresetDraft((current) => ({ ...current, rate: event.target.value }))} placeholder="145.00" /></label>
          </div>
          <div className="preset-editor__actions">
            <button type="button" className="estimate-form__secondary" onClick={savePreset}>{presetDraft.id ? "Update preset" : "Save preset"}</button>
            {presetDraft.id && <button type="button" className="text-button" onClick={() => setPresetDraft(emptyPreset)}>Cancel</button>}
          </div>
        </div>
        {presetStatus === "success" && <p className="form-note form-note--ok">Preset settings saved.</p>}
        {presetStatus === "error" && <p className="form-note form-note--error">{presetError}</p>}
      </section>

      <section className="estimate-form__section">
        <div className="section-heading">
          <div><h3>Saved roof packages</h3><span>Group materials and services to add a complete assembly in order.</span></div>
          <button type="button" className="text-button" onClick={() => { setPackageDraft(emptyPackage); setPackageError(""); }}>New package</button>
        </div>
        <div className="package-list">
          {packages.length === 0 && <p className="empty-line-items">No packages yet. Create one from your saved materials and services.</p>}
          {packages.map((savedPackage) => {
            const packageItems = (savedPackage.presetIds || [])
              .map((presetId) => presets.find((preset) => preset.id === presetId))
              .filter(Boolean);
            return (
              <div className="package-row" key={savedPackage.id}>
                <div>
                  <strong>{savedPackage.name}</strong>
                  <small>{packageItems.length} {packageItems.length === 1 ? "row" : "rows"} · {packageItems.map((preset) => preset.name).join(" · ")}</small>
                </div>
                <div className="preset-row__actions">
                  <button type="button" className="text-button" onClick={() => addPackage(savedPackage)} disabled={!packageItems.length}>Use package</button>
                  <button type="button" className="text-button" onClick={() => editPackage(savedPackage)}>Edit</button>
                  <button type="button" className="text-button text-button--danger" onClick={() => deletePackage(savedPackage.id)}>Delete</button>
                </div>
              </div>
            );
          })}
        </div>
        <div className="package-editor">
          <p className="preset-editor__title">{packageDraft.id ? "Edit saved package" : "Save a reusable roof package"}</p>
          <label className="package-editor__name"><span>Package name</span><input value={packageDraft.name} onChange={(event) => setPackageDraft((current) => ({ ...current, name: event.target.value }))} placeholder="Asphalt replacement" /></label>
          <div className="package-editor__columns">
            <div>
              <p className="package-editor__label">Rows in saved order</p>
              <div className="package-members">
                {packageDraft.presetIds.length === 0 && <p className="empty-line-items">Add saved materials or services here.</p>}
                {packageDraft.presetIds.map((presetId, index) => {
                  const preset = presets.find((item) => item.id === presetId);
                  return (
                    <div className="package-member" key={`${presetId}-${index}`}>
                      <span><strong>{index + 1}.</strong> {preset?.name || "Unavailable preset"}</span>
                      <span className="package-member__actions">
                        <button type="button" className="icon-button" onClick={() => movePackagePreset(index, -1)} disabled={index === 0} aria-label={`Move ${preset?.name || "package row"} up`}>↑</button>
                        <button type="button" className="icon-button" onClick={() => movePackagePreset(index, 1)} disabled={index === packageDraft.presetIds.length - 1} aria-label={`Move ${preset?.name || "package row"} down`}>↓</button>
                        <button type="button" className="text-button text-button--danger" onClick={() => removePresetFromPackage(presetId)}>Remove</button>
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
            <div>
              <p className="package-editor__label">Available saved rows</p>
              <div className="package-available">
                {presets.filter((preset) => !packageDraft.presetIds.includes(preset.id)).map((preset) => (
                  <div className="package-member" key={preset.id}>
                    <span><strong>{preset.name}</strong><small>{preset.category} · {unitLabel(preset.unit)} · {money(preset.rate)}</small></span>
                    <button type="button" className="text-button" onClick={() => addPresetToPackage(preset.id)}>Add</button>
                  </div>
                ))}
                {presets.length === packageDraft.presetIds.length && <p className="empty-line-items">All saved rows are included.</p>}
              </div>
            </div>
          </div>
          <div className="preset-editor__actions">
            <button type="button" className="estimate-form__secondary" onClick={savePackage}>{packageDraft.id ? "Update package" : "Save package"}</button>
            {packageDraft.id && <button type="button" className="text-button" onClick={() => setPackageDraft(emptyPackage)}>Cancel</button>}
          </div>
        </div>
        {packageStatus === "success" && <p className="form-note form-note--ok">Package settings saved.</p>}
        {packageStatus === "error" && <p className="form-note form-note--error">{packageError}</p>}
      </section>

      <section className="estimate-form__section">
        <div className="section-heading"><div><h3>Pricing defaults</h3><span>Overhead, markup, and tax apply to this estimate.</span></div><button type="button" className="text-button" onClick={saveDefaults} disabled={presetStatus === "saving"}>Save defaults</button></div>
        <div className="field-grid field-grid--pricing">
          <label><span>Overhead (%)</span><input name="overheadPercent" type="number" min="0" max="100" step="0.5" value={pricing.overheadPercent} onChange={changePricing} /></label>
          <label><span>Markup (%)</span><input name="markupPercent" type="number" min="0" max="100" step="0.5" value={pricing.markupPercent} onChange={changePricing} /></label>
          <label><span>Tax (%)</span><input name="taxPercent" type="number" min="0" max="100" step="0.5" value={pricing.taxPercent} onChange={changePricing} /></label>
        </div>
      </section>

      <section className="estimate-form__section">
        <h3>Estimate breakdown</h3>
        <div className="line-items">
          {pricedLineItems.map((item) => <div className="line-item" key={item.id}><span>{item.name}<small>{item.quantity.toFixed(2)} {unitLabel(item.unit)} × {money(item.rate)}</small></span><strong>{money(item.total)}</strong></div>)}
        </div>
        <div className="totals">
          <div><span>Subtotal</span><strong>{money(totals.subtotal)}</strong></div>
          <div><span>Overhead</span><strong>{money(totals.overhead)}</strong></div>
          <div><span>Markup</span><strong>{money(totals.markedUp)}</strong></div>
          <div><span>Tax</span><strong>{money(totals.tax)}</strong></div>
          <div className="totals__grand"><span>Estimated total</span><strong>{money(totals.total)}</strong></div>
        </div>
      </section>

      <button className="estimate-form__submit" type="submit" disabled={status === "saving"}>{status === "saving" ? "Saving…" : initialEstimate ? "Save estimate" : "Save draft estimate"}</button>
      {status === "success" && <p className="form-note form-note--ok">Estimate saved.</p>}
      {status === "error" && <p className="form-note form-note--error" role="alert">{error}</p>}
    </form>
  );
}