import React, { useState } from "react";
import { createJob } from "../api/client";
import "./JobForm.css";

export default function JobForm({ onJobCreated }) {
  const [address, setAddress] = useState("");
  const [homeownerId, setHomeownerId] = useState("");
  const [status, setStatus] = useState("idle"); // idle | saving | success | error
  const [error, setError] = useState("");

  const submitJob = async (e) => {
    e.preventDefault();

    if (!homeownerId.trim() || !address.trim()) {
      setStatus("error");
      setError("Homeowner ID and address are both required.");
      return;
    }

    setStatus("saving");
    setError("");

    try {
      await createJob({
        event_name: "JobCreated",
        version: 1,
        timestamp: new Date().toISOString(),
        source: "Frontend",
        job_id: Math.floor(Math.random() * 100000),
        payload: {
          homeowner_id: Number(homeownerId),
          address: address.trim(),
          lead_source: "netlify_frontend",
        },
      });

      setStatus("success");
      setAddress("");
      setHomeownerId("");
      onJobCreated?.();
    } catch (err) {
      setStatus("error");
      setError(err.message);
    }
  };

  return (
    <form className="job-form" onSubmit={submitJob}>
      <h2 className="job-form__title">New job</h2>

      <label className="job-form__field">
        <span>Homeowner ID</span>
        <input
          value={homeownerId}
          onChange={(e) => setHomeownerId(e.target.value)}
          placeholder="10245"
          inputMode="numeric"
        />
      </label>

      <label className="job-form__field">
        <span>Property address</span>
        <input
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          placeholder="118 Birch St, Broomfield, CO"
        />
      </label>

      <button className="job-form__submit" type="submit" disabled={status === "saving"}>
        {status === "saving" ? "Submitting…" : "Submit job"}
      </button>

      {status === "success" && (
        <p className="job-form__note job-form__note--ok">Job submitted.</p>
      )}
      {status === "error" && (
        <p className="job-form__note job-form__note--error">{error}</p>
      )}
    </form>
  );
}
