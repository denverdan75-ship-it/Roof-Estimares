import React, { useEffect, useRef, useState } from "react";
import { deleteEstimateDocument, downloadDocumentPacket, listEstimateDocuments, uploadEstimateDocument } from "../api/client";
import { trackEvent } from "../analytics";

const MAX_FILE_BYTES = 10 * 1024 * 1024;

const fileToBase64 = (file) => new Promise((resolve, reject) => {
  const reader = new FileReader();
  reader.onload = () => resolve(String(reader.result).split(",")[1]);
  reader.onerror = reject;
  reader.readAsDataURL(file);
});

const sizeLabel = (bytes) => bytes < 1024 * 1024
  ? `${Math.ceil(bytes / 1024)} KB`
  : `${(bytes / (1024 * 1024)).toFixed(1)} MB`;

export default function EstimateDocuments({ estimateId }) {
  const inputRef = useRef(null);
  const photoInputRef = useRef(null);
  const cameraInputRef = useRef(null);
  const [documents, setDocuments] = useState([]);
  const [status, setStatus] = useState("loading");
  const [message, setMessage] = useState("");
  const [selected, setSelected] = useState([]);

  const load = async () => {
    if (!estimateId) return;
    setStatus("loading");
    try {
      setDocuments(await listEstimateDocuments(estimateId));
      setSelected([]);
      setStatus("ready");
    } catch {
      setStatus("error");
    }
  };

  useEffect(() => { load(); }, [estimateId]);

  const upload = async (event, photosOnly = false) => {
    const files = [...(event.target.files || [])];
    if (!files.length) return;
    const invalidPhoto = photosOnly && files.find((file) => !file.type.startsWith("image/"));
    if (invalidPhoto) {
      setMessage(`${invalidPhoto.name} is not a supported photo.`);
      event.target.value = "";
      return;
    }
    const oversized = files.find((file) => file.size > MAX_FILE_BYTES);
    if (oversized) {
      setMessage(`${oversized.name} is larger than the 10 MB limit.`);
      event.target.value = "";
      return;
    }
    setStatus("saving");
    setMessage("");
    try {
      for (const file of files) {
        await uploadEstimateDocument(estimateId, {
          name: file.name,
          type: file.type || "application/octet-stream",
          size: file.size,
          content: await fileToBase64(file),
        });
      }
      trackEvent("estimate_documents_uploaded", {
        file_count: files.length,
        includes_photo: files.some((file) => file.type.startsWith("image/")),
      });
      event.target.value = "";
      await load();
    } catch (error) {
      setStatus("error");
      setMessage(error.message);
    }
  };

  const remove = async (documentId) => {
    setStatus("saving");
    try {
      await deleteEstimateDocument(estimateId, documentId);
      trackEvent("estimate_document_deleted");
      await load();
    } catch (error) {
      setStatus("error");
      setMessage(error.message);
    }
  };

  const toggle = (documentId) => {
    setSelected((current) => current.includes(documentId)
      ? current.filter((id) => id !== documentId)
      : [...current, documentId]);
  };

  const buildPacket = async (format) => {
    setStatus("saving");
    setMessage("");
    try {
      await downloadDocumentPacket(estimateId, selected, format);
      setStatus("ready");
    } catch (error) {
      setStatus("error");
      setMessage(error.message);
    }
  };

  const selectedDocuments = documents.filter((document) => selected.includes(document.document_id));
  const photos = documents.filter((document) => document.type.startsWith("image/"));
  const files = documents.filter((document) => !document.type.startsWith("image/"));
  const pdfEligible = selectedDocuments.length > 0 && selectedDocuments.every((document) =>
    ["application/pdf", "image/jpeg", "image/png"].includes(document.type));

  return (
    <div className="document-box">
      <section className="estimate-photos">
        <div className="estimate-photos__header">
          <div>
            <strong>Job photos</strong>
            <span>Take photos at the property or add them from your device.</span>
          </div>
          <div className="estimate-photos__actions">
            <input
              ref={cameraInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={(event) => upload(event, true)}
            />
            <input
              ref={photoInputRef}
              type="file"
              accept="image/*"
              multiple
              onChange={(event) => upload(event, true)}
            />
            <button type="button" onClick={() => cameraInputRef.current?.click()} disabled={status === "saving"}>
              Take photo
            </button>
            <button type="button" onClick={() => photoInputRef.current?.click()} disabled={status === "saving"}>
              Add photos
            </button>
          </div>
        </div>
        {photos.length === 0 && status !== "loading" && (
          <div className="estimate-photos__empty">No job photos added yet.</div>
        )}
        {photos.length > 0 && (
          <div className="estimate-photos__grid">
            {photos.map((photo) => (
              <article className="photo-card" key={photo.document_id}>
                <a
                  className="photo-card__image"
                  href={`/estimates/${estimateId}/documents/${photo.document_id}/download`}
                  target="_blank"
                  rel="noreferrer"
                >
                  <img
                    src={`/estimates/${estimateId}/documents/${photo.document_id}/download`}
                    alt={photo.name}
                    loading="lazy"
                  />
                </a>
                <div className="photo-card__details">
                  <label>
                    <input type="checkbox" checked={selected.includes(photo.document_id)} onChange={() => toggle(photo.document_id)} />
                    <span title={photo.name}>{photo.name}</span>
                  </label>
                  <button type="button" onClick={() => remove(photo.document_id)} aria-label={`Remove ${photo.name}`}>Remove</button>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>
      <div className="document-box__drop">
        <input ref={inputRef} type="file" multiple onChange={(event) => upload(event)} />
        <strong>Estimate document box</strong>
        <span>Scans, PDFs, Word, Excel, and other common files. 10 MB per file.</span>
        <button type="button" onClick={() => inputRef.current?.click()} disabled={status === "saving"}>
          {status === "saving" ? "Uploading…" : "Add documents"}
        </button>
      </div>
      {status === "loading" && <p className="document-box__note">Loading documents…</p>}
      {message && <p className="document-box__note document-box__note--error">{message}</p>}
      {status !== "loading" && documents.length === 0 && <p className="document-box__note">No documents attached yet.</p>}
      {documents.length > 0 && (
        <>
          <div className="document-packet">
            <label>
              <input
                type="checkbox"
                checked={selected.length === documents.length}
                onChange={() => setSelected(selected.length === documents.length ? [] : documents.map((document) => document.document_id))}
              />
              Select all
            </label>
            <span>{selected.length} selected</span>
            <button type="button" disabled={!selected.length || status === "saving"} onClick={() => buildPacket("zip")}>Download ZIP packet</button>
            <button type="button" disabled={!pdfEligible || status === "saving"} onClick={() => buildPacket("pdf")}>Download PDF packet</button>
          </div>
          {!pdfEligible && selected.length > 0 && (
            <p className="document-box__note">PDF packets can include PDFs, JPGs, and PNGs only. ZIP supports every file type.</p>
          )}
          {files.length > 0 && <div className="document-list">
          {files.map((document) => (
            <div className="document-row" key={document.document_id}>
              <label className="document-row__select">
                <input type="checkbox" checked={selected.includes(document.document_id)} onChange={() => toggle(document.document_id)} />
                <span><strong>{document.name}</strong><small>{sizeLabel(document.size)} · {new Date(document.created_at).toLocaleDateString()}</small></span>
              </label>
              <div>
                <a href={`/estimates/${estimateId}/documents/${document.document_id}/download`}>Download</a>
                <button type="button" onClick={() => remove(document.document_id)}>Remove</button>
              </div>
            </div>
          ))}
          </div>}
        </>
      )}
    </div>
  );
}