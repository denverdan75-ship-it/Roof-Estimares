import React from "react";
import "./ProposalPreview.css";

const money = (value) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(value || 0);

const dateLabel = (value) =>
  new Intl.DateTimeFormat("en-US", { dateStyle: "long" }).format(value ? new Date(value) : new Date());

const externalUrl = (value) =>
  /^https?:\/\//i.test(value || "") ? value : `https://${value}`;

export default function ProposalPreview({ estimate, onBack }) {
  const proposal = estimate.proposal || {};
  const measurements = estimate.measurements || {};
  const totals = estimate.totals || {};

  return (
    <article className="proposal">
      <div className="proposal-actions">
        <button className="text-button" type="button" onClick={onBack}>Back to estimates</button>
        <button className="proposal-actions__print" type="button" onClick={() => window.print()}>Print / Save PDF</button>
      </div>

      <header className="proposal__header">
        <div className="proposal__brand">
          <img className="proposal__logo" src="/brand/dragonfly-roofing-logo.jpg" alt="Dragonfly Roofing Company" />
          <p className="eyebrow">Roofing proposal</p>
          <h1>{proposal.companyName || "Roofing Estimate"}</h1>
          <p className="proposal__contact">
            {[proposal.companyAddress, proposal.companyPhone, proposal.companyEmail].filter(Boolean).join(" · ")}
          </p>
          {proposal.companyWebsite && (
            <a className="proposal__website" href={externalUrl(proposal.companyWebsite)} target="_blank" rel="noreferrer">
              {proposal.companyWebsite}
            </a>
          )}
          {(proposal.companyFacebook || proposal.companyInstagram) && (
            <nav className="proposal__socials" aria-label="Company social media">
              {proposal.companyFacebook && (
                <a href={externalUrl(proposal.companyFacebook)} target="_blank" rel="noreferrer">Facebook</a>
              )}
              {proposal.companyInstagram && (
                <a href={externalUrl(proposal.companyInstagram)} target="_blank" rel="noreferrer">Instagram</a>
              )}
            </nav>
          )}
        </div>
        <div className="proposal__meta">
          <strong>Estimate #{estimate.estimate_id}</strong>
          <span>{dateLabel(estimate.updated_at || estimate.created_at)}</span>
          <span className="proposal__status">{estimate.status || "Draft"}</span>
        </div>
      </header>

      <section className="proposal__client">
        <div><span>Prepared for</span><strong>{estimate.customerName}</strong><p>{estimate.address}</p></div>
        <div><span>Roof size</span><strong>{Number(measurements.squares || 0).toFixed(2)} squares</strong><p>{Number(measurements.baseSqFt || 0).toFixed(0)} sq. ft. base area · {measurements.wastePercent || 0}% waste</p></div>
      </section>

      <section className="proposal__section">
        <h2>Scope of work</h2>
        <p>{proposal.scopeOfWork || "Roofing work as discussed with the homeowner."}</p>
      </section>

      <section className="proposal__section">
        <h2>Investment</h2>
        <table className="proposal__table">
          <thead><tr><th>Description</th><th>Quantity</th><th>Rate</th><th>Total</th></tr></thead>
          <tbody>
            {(estimate.lineItems || []).map((item) => (
              <tr key={item.id || item.name}>
                <td>{item.name}</td>
                <td>{Number(item.quantity || 0).toFixed(2)} {item.unit || ""}</td>
                <td>{money(item.rate)}</td>
                <td>{money(item.total)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="proposal__totals">
          <div><span>Subtotal</span><strong>{money(totals.subtotal)}</strong></div>
          <div><span>Overhead</span><strong>{money(totals.overhead)}</strong></div>
          <div><span>Markup</span><strong>{money(totals.markedUp)}</strong></div>
          <div><span>Tax</span><strong>{money(totals.tax)}</strong></div>
          <div className="proposal__grand-total"><span>Estimated total</span><strong>{money(totals.total)}</strong></div>
        </div>
      </section>

      <section className="proposal__notes">
        <div><h2>Exclusions and notes</h2><p>{proposal.exclusions || "No additional exclusions noted."}</p></div>
        <div><h2>Terms and conditions</h2><p>{proposal.terms || "Please contact us with any questions about this estimate."}</p></div>
      </section>

      <footer className="proposal__acceptance">
        <p>By signing below, I approve the scope of work and estimated total shown above.</p>
        <div><span>Customer signature</span><span>Date</span></div>
      </footer>
    </article>
  );
}