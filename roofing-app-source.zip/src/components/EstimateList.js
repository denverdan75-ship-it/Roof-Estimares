import React, { useCallback, useEffect, useState } from "react";
import { deleteEstimate, listEstimates } from "../api/client";
import { trackEvent } from "../analytics";
import "./EstimateList.css";

const money = (value) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(value || 0);

export default function EstimateList({ refreshKey, onSelect, onPreview, onDeleted }) {
  const [estimates, setEstimates] = useState([]);
  const [status, setStatus] = useState("loading");
  const [error, setError] = useState("");
  const [pendingDelete, setPendingDelete] = useState(null);
  const [password, setPassword] = useState("");
  const [deleteError, setDeleteError] = useState("");
  const [deleting, setDeleting] = useState(false);

  const load = useCallback(async () => {
    setStatus("loading");
    try {
      setEstimates(await listEstimates());
      setStatus("ready");
    } catch (err) {
      setError(err.message);
      setStatus("error");
    }
  }, []);

  useEffect(() => { load(); }, [load, refreshKey]);

  const requestDelete = (estimate) => {
    setPendingDelete(estimate);
    setPassword("");
    setDeleteError("");
  };

  const cancelDelete = () => {
    if (deleting) return;
    setPendingDelete(null);
    setPassword("");
    setDeleteError("");
  };

  const confirmDelete = async (event) => {
    event.preventDefault();
    setDeleting(true);
    setDeleteError("");
    try {
      await deleteEstimate(pendingDelete.estimate_id, password);
      trackEvent("estimate_deleted", {
        status: pendingDelete.status || "Draft",
      });
      setPendingDelete(null);
      setPassword("");
      await load();
      onDeleted?.();
    } catch (deleteRequestError) {
      setDeleteError(deleteRequestError.message.includes("403")
        ? "The administrator password is incorrect."
        : "The estimate could not be deleted.");
    } finally {
      setDeleting(false);
    }
  };

  return (
    <section className="estimate-list">
      <div className="estimate-list__header">
        <div><p className="eyebrow">Saved work</p><h2>Estimates</h2></div>
        <button className="text-button" onClick={load} type="button">Refresh</button>
      </div>
      {status === "loading" && <p className="estimate-list__note">Loading estimates…</p>}
      {status === "error" && <p className="estimate-list__note estimate-list__note--error">Couldn’t load estimates: {error}</p>}
      {status === "ready" && estimates.length === 0 && <p className="estimate-list__note">No estimates yet. Build the first one on the left.</p>}
      {status === "ready" && estimates.length > 0 && (
        <div className="estimate-list__items">
          {estimates.map((estimate) => (
            <div className="estimate-card-row" key={estimate.estimate_id}>
              <button className="estimate-card" onClick={() => onSelect?.(estimate)} type="button">
                <span className="estimate-card__number">#{estimate.estimate_id}</span>
                <span className="estimate-card__main"><strong>{estimate.customerName}</strong><small>{estimate.address}</small></span>
                <span className="estimate-card__amount"><strong>{money(estimate.totals?.total)}</strong><small>{estimate.measurements?.squares?.toFixed?.(2) || "0.00"} squares · {estimate.status}</small></span>
              </button>
              <button className="estimate-card__proposal" onClick={() => onPreview?.(estimate)} type="button">Proposal</button>
              <button className="estimate-card__delete" onClick={() => requestDelete(estimate)} type="button">Delete</button>
            </div>
          ))}
        </div>
      )}
      {pendingDelete && (
        <div className="delete-confirm" role="presentation" onMouseDown={(event) => event.target === event.currentTarget && cancelDelete()}>
          <form className="delete-confirm__dialog" role="dialog" aria-modal="true" aria-labelledby="delete-estimate-title" onSubmit={confirmDelete}>
            <p className="eyebrow">Admin confirmation</p>
            <h3 id="delete-estimate-title">Delete estimate #{pendingDelete.estimate_id}?</h3>
            <p>
              This permanently deletes the estimate for <strong>{pendingDelete.customerName}</strong>,
              including its uploaded documents and job photos. This cannot be undone.
            </p>
            <label>
              Administrator password
              <input
                type="password"
                name="delete-password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                autoComplete="current-password"
                autoFocus
                required
              />
            </label>
            {deleteError && <div className="delete-confirm__error" role="alert">{deleteError}</div>}
            <div className="delete-confirm__actions">
              <button type="button" onClick={cancelDelete} disabled={deleting}>Cancel</button>
              <button type="submit" disabled={deleting || !password}>{deleting ? "Deleting…" : "Permanently delete"}</button>
            </div>
          </form>
        </div>
      )}
    </section>
  );
}