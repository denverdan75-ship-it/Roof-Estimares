// Same-origin API calls — Express serves the dashboard and API together.

async function request(path, options = {}) {
  const res = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });

  if (!res.ok) {
    const body = await res.text().catch(() => "");
    let message = body || res.statusText;
    try {
      const payload = JSON.parse(body);
      if (payload?.error) message = payload.error;
    } catch {
      // Keep the raw response when the server did not return JSON.
    }
    throw new Error(`Request failed (${res.status}): ${message}`);
  }

  return res.json();
}

export function getAuthSession() {
  return request("/api/auth/session");
}

export function login(password) {
  return request("/api/auth/login", {
    method: "POST",
    body: JSON.stringify({ password }),
  });
}

export function logout() {
  return request("/api/auth/logout", { method: "POST" });
}

export function submitLead(lead) {
  return request("/submit-lead", {
    method: "POST",
    body: JSON.stringify(lead),
  });
}

export function createJob(jobPayload) {
  return request("/jobs", {
    method: "POST",
    body: JSON.stringify(jobPayload),
  });
}

export function listJobs() {
  return request("/jobs");
}

export function getPricingSettings() {
  return request("/pricing-settings");
}

export function savePricingSettings(settings) {
  return request("/pricing-settings", {
    method: "PUT",
    body: JSON.stringify(settings),
  });
}

export function listPricingPresets() {
  return request("/pricing-presets");
}

export function createPricingPreset(preset) {
  return request("/pricing-presets", {
    method: "POST",
    body: JSON.stringify(preset),
  });
}

export function updatePricingPreset(id, preset) {
  return request(`/pricing-presets/${id}`, {
    method: "PUT",
    body: JSON.stringify(preset),
  });
}

export function deletePricingPreset(id) {
  return request(`/pricing-presets/${id}`, { method: "DELETE" });
}

export function listPricingPackages() {
  return request("/pricing-packages");
}
export function listEstimates() {
  return request("/estimates");
}

export function listLeads() {
  return request("/leads");
}

export function createEstimate(estimate) {
  return request("/estimates", {
    method: "POST",
    body: JSON.stringify(estimate),
  });
}

export function updateEstimate(id, estimate) {
  return request(`/estimates/${id}`, {
    method: "PUT",
    body: JSON.stringify(estimate),
  });
}

export function updateEstimateStatus(id, status) {
  return request(`/estimates/${id}/status`, {
    method: "PATCH",
    body: JSON.stringify({ status }),
  });
}

export function deleteEstimate(id, password) {
  return request(`/estimates/${id}`, {
    method: "DELETE",
    body: JSON.stringify({ password }),
  });
}

export function listEstimateDocuments(estimateId) {
  return request(`/estimates/${estimateId}/documents`);
}

export function uploadEstimateDocument(estimateId, document) {
  return request(`/estimates/${estimateId}/documents`, {
    method: "POST",
    body: JSON.stringify(document),
  });
}

export function deleteEstimateDocument(estimateId, documentId) {
  return request(`/estimates/${estimateId}/documents/${documentId}`, { method: "DELETE" });
}

export async function downloadDocumentPacket(estimateId, documentIds, format) {
  const response = await fetch(`/estimates/${estimateId}/document-packet`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ documentIds, format }),
  });
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.error || `Packet creation failed (${response.status})`);
  }
  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `estimate-${estimateId}-customer-packet.${format}`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

export function deletePricingPackage(id) {
  return request(`/pricing-packages/${id}`, { method: "DELETE" });
}

export function updatePricingPackage(id, packagePayload) {
  return request(`/pricing-packages/${id}`, {
    method: "PUT",
    body: JSON.stringify(packagePayload),
  });
}

export function createPricingPackage(packagePayload) {
  return request("/pricing-packages", {
    method: "POST",
    body: JSON.stringify(packagePayload),
  });
}
