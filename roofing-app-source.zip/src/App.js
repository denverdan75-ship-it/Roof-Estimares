import React, { useEffect, useState } from "react";
import EstimateForm from "./components/EstimateForm";
import EstimateList from "./components/EstimateList";
import ProposalPreview from "./components/ProposalPreview";
import JobDashboard from "./components/JobDashboard";
import { getAuthSession, login, logout, submitLead } from "./api/client";
import { trackEvent } from "./analytics";
import "./App.css";

function IntakeLink() {
  const [message, setMessage] = useState("");
  const url = new URL("/?intake=1", window.location.origin).href;
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(url);
      setMessage("Intake link copied.");
    } catch {
      setMessage("Copy the link from the field below.");
    }
  };
  return (
    <div className="intake-share">
      <a href="/?intake=1">Customer Intake</a>
      <button type="button" onClick={copy}>Copy intake link</button>
      {message && <div role="status">
        {message}
        <input aria-label="Customer intake link" value={url} readOnly onFocus={(event) => event.target.select()} />
      </div>}
    </div>
  );
}

function SignIn({ onSignedIn }) {
  const [accessView, setAccessView] = useState("intake");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [intake, setIntake] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
    serviceType: "",
    website: "",
  });
  const [intakeStatus, setIntakeStatus] = useState("idle");
  const [intakeError, setIntakeError] = useState("");

  const submit = async (event) => {
    event.preventDefault();
    setSaving(true);
    setError("");
    try {
      await login(password);
      onSignedIn();
    } catch (requestError) {
      setError(requestError.message.includes("429")
        ? "Too many attempts. Try again in 15 minutes."
        : "That password is incorrect.");
      setSaving(false);
    }
  };

  const submitIntake = async (event) => {
    event.preventDefault();
    setIntakeStatus("saving");
    setIntakeError("");
    try {
      await submitLead({
        name: intake.name,
        phone: intake.phone,
        email: intake.email,
        address: intake.address,
        service_type: intake.serviceType,
        website: intake.website,
      });
      trackEvent("customer_intake_submitted", {
        contact_method: intake.phone.trim() && intake.email.trim()
          ? "phone_and_email"
          : intake.phone.trim() ? "phone" : "email",
        service_selected: Boolean(intake.serviceType),
        address_provided: Boolean(intake.address.trim()),
      });
      setIntakeStatus("saved");
      setIntake({ name: "", phone: "", email: "", address: "", serviceType: "", website: "" });
    } catch (requestError) {
      setIntakeStatus("error");
      setIntakeError(requestError.message.includes("429")
        ? "Too many requests were received. Please try again later."
        : "Your information could not be sent. Please try again.");
    }
  };

  const updateIntake = (field) => (event) => {
    setIntake((current) => ({ ...current, [field]: event.target.value }));
    if (intakeStatus === "saved") setIntakeStatus("idle");
  };

  return (
    <main className="sign-in-shell">
      <section className={`sign-in-card ${accessView === "intake" ? "sign-in-card--intake" : ""}`}>
        <img src="/brand/dragonfly-roofing-logo.jpg" alt="Dragonfly Roofing Company" />
        <IntakeLink />
        {new URLSearchParams(window.location.search).has("intake") && <a href="/">Back to workspace</a>}
        <div className="access-tabs" role="tablist" aria-label="Access options">
          <button type="button" className={accessView === "intake" ? "is-active" : ""} onClick={() => setAccessView("intake")}>Customer Intake</button>
          <button type="button" className={accessView === "admin" ? "is-active" : ""} onClick={() => setAccessView("admin")}>Team Sign In</button>
        </div>

        {accessView === "intake" ? (
          <form className="intake-form" onSubmit={submitIntake}>
            <p className="sign-in-card__eyebrow">Request an estimate</p>
            <h1>Customer Intake</h1>
            <p>Tell us about your property and our roofing team will contact you.</p>
            <label>
              Full name
              <input value={intake.name} onChange={updateIntake("name")} autoComplete="name" required />
            </label>
            <div className="intake-form__contact">
              <label>
                Phone
                <input type="tel" value={intake.phone} onChange={updateIntake("phone")} autoComplete="tel" />
              </label>
              <label>
                Email
                <input type="email" value={intake.email} onChange={updateIntake("email")} autoComplete="email" />
              </label>
            </div>
            <p className="intake-form__hint">Please provide a phone number or email.</p>
            <label>
              Property address
              <input value={intake.address} onChange={updateIntake("address")} autoComplete="street-address" />
            </label>
            <label>
              Roofing service needed
              <select value={intake.serviceType} onChange={updateIntake("serviceType")}>
                <option value="">Select a service</option>
                <option>Roof inspection</option>
                <option>Roof repair</option>
                <option>Roof replacement</option>
                <option>Storm damage</option>
                <option>Other roofing service</option>
              </select>
            </label>
            <label className="intake-form__website" aria-hidden="true">
              Website
              <input value={intake.website} onChange={updateIntake("website")} tabIndex="-1" autoComplete="off" />
            </label>
            {intakeStatus === "saved" && <div className="sign-in-card__success" role="status">Thank you. Your information was sent to our roofing team.</div>}
            {intakeError && <div className="sign-in-card__error" role="alert">{intakeError}</div>}
            <button type="submit" disabled={intakeStatus === "saving" || (!intake.phone.trim() && !intake.email.trim())}>
              {intakeStatus === "saving" ? "Sending…" : "Send to Roofing Team"}
            </button>
          </form>
        ) : (
          <form onSubmit={submit}>
            <p className="sign-in-card__eyebrow">Protected workspace</p>
            <h1>Roofing Operations</h1>
            <p>Sign in to access customer records, estimates, job photos, and pricing.</p>
            <label>
              Administrator password
              <input type="text" name="username" autoComplete="username" value="administrator" readOnly hidden />
              <input
                type="password"
                name="password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                autoComplete="current-password"
                autoFocus
                required
              />
            </label>
            {error && <div className="sign-in-card__error" role="alert">{error}</div>}
            <button type="submit" disabled={saving}>{saving ? "Signing in…" : "Sign in"}</button>
          </form>
        )}
      </section>
    </main>
  );
}

export default function App() {
  const [authState, setAuthState] = useState("loading");
  const [refreshKey, setRefreshKey] = useState(0);
  const [selectedEstimate, setSelectedEstimate] = useState(null);
  const [previewEstimate, setPreviewEstimate] = useState(null);
  const [view, setView] = useState("dashboard");

  useEffect(() => {
    getAuthSession()
      .then(({ authenticated }) => setAuthState(authenticated ? "signed-in" : "signed-out"))
      .catch(() => setAuthState("signed-out"));
  }, []);

  const signOut = async () => {
    await logout();
    setSelectedEstimate(null);
    setPreviewEstimate(null);
    setAuthState("signed-out");
  };

  if (new URLSearchParams(window.location.search).get("intake") === "1") {
    return <SignIn onSignedIn={() => { window.location.assign("/"); }} />;
  }

  if (authState === "loading") {
    return <main className="auth-loading">Loading secure workspace…</main>;
  }

  if (authState === "signed-out") {
    return <SignIn onSignedIn={() => setAuthState("signed-in")} />;
  }

  if (previewEstimate) {
    return (
      <div className="app">
        <header className="app__header">
          <div className="app__header-inner">
            <img className="app__logo" src="/brand/dragonfly-roofing-logo.jpg" alt="Dragonfly Roofing Company" />
            <div>
              <h1 className="app__title">Roofing Estimates</h1>
              <p className="app__subtitle">Customer proposal preview</p>
            </div>
            <nav className="app__nav" aria-label="Primary navigation">
              <IntakeLink />
              <button type="button" onClick={() => { setPreviewEstimate(null); setView("dashboard"); }}>Dashboard</button>
              <button type="button" onClick={() => { setPreviewEstimate(null); setView("estimator"); }}>Estimator</button>
              <button type="button" onClick={signOut}>Sign out</button>
            </nav>
          </div>
        </header>
        <main className="proposal-shell">
          <ProposalPreview estimate={previewEstimate} onBack={() => setPreviewEstimate(null)} />
        </main>
      </div>
    );
  }

  return (
    <div className="app">
      <header className="app__header">
        <div className="app__header-inner">
          <img className="app__logo" src="/brand/dragonfly-roofing-logo.jpg" alt="Dragonfly Roofing Company" />
          <div>
            <h1 className="app__title">{view === "dashboard" ? "Customer & Job Dashboard" : "Roofing Estimates"}</h1>
            <p className="app__subtitle">{view === "dashboard" ? "Your estimating pipeline at a glance." : "Build accurate proposals from the measurements you already have."}</p>
          </div>
          <nav className="app__nav" aria-label="Primary navigation">
            <IntakeLink />
            <button className={view === "dashboard" ? "is-active" : ""} type="button" onClick={() => setView("dashboard")}>Dashboard</button>
            <button className={view === "estimator" ? "is-active" : ""} type="button" onClick={() => { setSelectedEstimate(null); setView("estimator"); }}>Estimator</button>
            <button type="button" onClick={signOut}>Sign out</button>
          </nav>
        </div>
      </header>

      {view === "dashboard" ? (
        <JobDashboard
          refreshKey={refreshKey}
          onNewEstimate={() => { setSelectedEstimate(null); setView("estimator"); }}
          onConvertLead={(lead) => {
            trackEvent("lead_conversion_started", {
              source: "new_leads",
              service_provided: Boolean(lead.service_type),
            });
            setSelectedEstimate({
              customerName: lead.name,
              phone: lead.phone,
              email: lead.email,
              address: lead.address,
              status: "Draft",
            });
            setView("estimator");
          }}
          onOpenEstimate={(estimate) => { setSelectedEstimate(estimate); setView("estimator"); }}
          onPreview={setPreviewEstimate}
        />
      ) : (
        <main className="app__main">
          <EstimateForm
            initialEstimate={selectedEstimate}
            onEstimateSaved={() => {
              setSelectedEstimate(null);
              setRefreshKey((k) => k + 1);
              setView("dashboard");
            }}
            onCancel={() => setSelectedEstimate(null)}
          />
          <EstimateList
            refreshKey={refreshKey}
            onSelect={setSelectedEstimate}
            onPreview={setPreviewEstimate}
            onDeleted={() => setRefreshKey((key) => key + 1)}
          />
        </main>
      )}
    </div>
  );
}
